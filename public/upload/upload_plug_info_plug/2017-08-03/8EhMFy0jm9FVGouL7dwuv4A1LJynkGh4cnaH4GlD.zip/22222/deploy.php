<?php
namespace Deployer;

require 'recipe/common.php';

// Configuration

set('repository', 'git@github.com:xishenma/backend_management.git');
set('git_tty', true); // [Optional] Allocate tty for git on first deployment
set('shared_files', ['.env']);
set('shared_dirs', ['logs']);
set('writable_dirs', ['shared/logs']);
set('writable_mode', 'chmod');
set('keep_releases',20);


// Hosts
host('39.108.163.234')
    ->stage('production')
    ->user('root')
    ->port(22)
    ->configFile('~/.ssh/config')
    ->identityFile('~/.ssh/id_rsa')
    ->forwardAgent(true)
    ->multiplexing(true)
    ->set('deploy_path', '/data/wwwroot/backend_management')
    ->set('branch', 'master')
    ->set('bin/php', '/usr/local/php/bin/php');

/**
 * Running npm
 */
task('deploy:npm', function () {
    if (has('previous_release')) {
        if (test('[ -d {{previous_release}}/node_modules ]')) {
            run('cp -R {{previous_release}}/node_modules {{release_path}}');
        }
    }
    run("cd {{release_path}} && /usr/bin/cnpm install");
})->desc("Running npm");

/**
 * Running gulp
 */
task('deploy:build', function () {
//    run("cd {{release_path}} && gulp --no-color clean styles admin-styles master-styles images fonts inject-prod-scripts");
    run("cd {{release_path}} && /usr/bin/npm run build");
})->desc("Running npm build");


desc('Deploy your project');
task('deploy', [
    'deploy:prepare',
    'deploy:lock',
    'deploy:release',
    'deploy:update_code',
    'deploy:shared',
    'deploy:writable',
    'deploy:vendors',
    'deploy:npm',
    'deploy:build',
    'deploy:clear_paths',
    'deploy:symlink',
    'deploy:unlock',
    'cleanup',
    'success'
]);

// [Optional] if deploy fails automatically unlock.
after('deploy:failed', 'deploy:unlock');