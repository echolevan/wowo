require 'mina/rails'
require 'mina/git'
# require 'mina/whenever'
require 'mina/bundler'
# require 'mina/rbenv'  # for rbenv support. (https://rbenv.org)
require 'mina/rvm'    # for rvm support. (https://rvm.io)

# Basic settings:
#   domain       - The hostname to SSH to.
#   deploy_to    - Path to deploy into.
#   repository   - Git repo to clone from. (needed by mina/git)
#   branch       - Branch name to deploy. (needed by mina/git)

set :application_name, 'backend_management'
set :domain, '180.76.159.130'
set :deploy_to, '/data/webapp/backend_management'
set :repository, 'git@github.com:xishenma/backend_management.git'
set :branch, ENV['branch'] || 'master'
set :user, 'root'
set :port, '22'
set :identity_file, '~/.ssh/id_rsa'

set :shared_paths, ['.env', 'logs']
set :shared_dirs, fetch(:shared_dirs, []).push('logs', 'tmp')
set :shared_files, fetch(:shared_files, []).push('.env')

task :environment do
end

task :setup => :environment do
  command %[mkdir -p "#{fetch(:deploy_to)}/shared/logs"]
  command %[chmod g+rx,u+rwx "#{fetch(:deploy_to)}/shared/logs"]

  command %[mkdir -p "#{fetch(:deploy_to)}/shared/config"]
  command %[chmod g+rx,u+rwx "#{fetch(:deploy_to)}/shared/config"]

  # command %[touch "#{fetch(:deploy_to)}/shared/config/db.php"]
end

desc "Deploys the current version to the server."
task :deploy => :environment do
  deploy do
    invoke :'git:clone'
    invoke :'deploy:link_shared_paths'
    command %[chown -R www-data "#{fetch(:deploy_to)}"]
    # command %{composer install}
    # command %{./bin/db migrate}
    # command %[service php7.0-fpm restart]
  end
end

