var merge = require('webpack-merge')
var prodEnv = require('./prod.env')

module.exports = merge(prodEnv, {
  NODE_ENV: '"development"',
  API_HOST: '"http://localhost:4004"'
  //API_HOST: '"https://backend.shenzg.com"'
})
  // API_HOST: '"http://backend_api.funxi.cn"'
