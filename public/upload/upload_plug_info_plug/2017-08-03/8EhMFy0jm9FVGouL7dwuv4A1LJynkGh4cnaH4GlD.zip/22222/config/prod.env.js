module.exports = {
  NODE_ENV: '"production"',
  API_HOST: '"https://backend-api2.funxi.cn"'
}
