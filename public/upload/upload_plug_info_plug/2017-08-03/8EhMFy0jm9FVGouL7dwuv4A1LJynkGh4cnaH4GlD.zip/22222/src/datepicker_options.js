let options = {
  type: 'day',
  week: ['周一', '周二', '周三', '周四', '周五', '周六', '周日'],
  month: ['一月', '二月', '三月', '四月', '五月', '六月', '七月', '八月', '九月', '十月', '十一月', '十二月'],
  format: 'YYYY-MM-DD',
  placeholder: '选择日期',
  inputStyle: {
    'display': 'inline-block',
    'padding': '6px',
    'line-height': '20px',
    'font-size': '14px',
    'border': '2px solid #fff',
    'box-shadow': '0 1px 3px 0 rgba(0, 0, 0, 0.2)',
    'border-radius': '2px',
    'color': '#5F5F5F'
  },
  color: {
    header: '#03A9F4',
    headerText: '#fff'
  },
  buttons: {
    ok: '确定',
    cancel: '取消'
  },
  overlayOpacity: 0.5, // 0.5 as default
  dismissible: true // as true as default
}
export default options
