import Buildings from '@/components/universities/Buildings'
import University from '@/components/universities/University'
import Universities from '@/components/universities/Universities'
import UniversityWashers from '@/components/universities/UniversityWashers'
import UniversityOrderList from '@/components/universities/UniversityOrderList'
import UniversityOrderStats from '@/components/universities/UniversityOrderStats'
import UniversitiesDefault from '@/components/universities/UniversitiesDefault'
import BuildingWashers from '@/components/universities/BuildingWashers'
import UniversityBuilding from '@/components/universities/UniversityBuilding'

const routes = [
  {
    path: '/universities',
    component: Universities,
    children: [
      { path: '', component: UniversitiesDefault, name: 'UniversitiesDefault' },
      {
        path: ':uid',
        component: University,
        children: [
          { path: '', component: UniversityOrderStats, name: 'UniversityOrderStats' },
          {
            path: 'buildings',
            component: Buildings,
            children: [
              { path: '', component: UniversityBuilding, name: 'UniversityBuildings' },
              { path: ':bid', component: UniversityBuilding, name: 'UniversityBuilding' },
              { path: ':bid/washers', component: BuildingWashers, name: 'BuildingWashers' }
            ]
          },
          { path: 'washers', component: UniversityWashers, name: 'UniversityWashers' },
          { path: 'orderList', component: UniversityOrderList, name: 'UniversityOrderList' }
        ]
      }
    ]
  }
]

export default routes
