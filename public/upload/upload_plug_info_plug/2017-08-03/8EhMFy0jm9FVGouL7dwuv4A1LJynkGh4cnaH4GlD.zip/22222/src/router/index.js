import Vue from 'vue'
import Router from 'vue-router'
import Home from '@/components/Home'
import Worker from '@/components/Worker'
import Workers from '@/components/Workers'
import WorkersDefault from '@/components/WorkersDefault'
import Users from '@/components/Users'
import Orders from '@/components/Orders'
import Washers from '@/components/Washers'
import Login from '@/components/Login'
import Vendors from '@/components/Vendors'
import Cities from '@/components/Cities'
import Operators from '@/components/Operators'
import OperatorsAccount from '@/components/OperatorsAccount'
import Services from '@/components/Services'
import Banners from '@/components/Banners'
import HaierTest from '@/components/HaierTest'

import universities from './universities'

Vue.use(Router)

let routes = [
  {
    path: '/',
    name: 'Index',
    component: Home
  },
  {
    path: '/home',
    name: 'Home',
    component: Home
  },
  {
    path: '/orders',
    name: 'Orders',
    component: Orders
  },
  {
    path: '/users',
    name: 'Users',
    component: Users
  },
  {
    path: '/washers',
    name: 'Washers',
    component: Washers
  },
  {
    path: '/vendors',
    name: 'Vendors',
    component: Vendors
  },
  {
    path: '/services',
    name: 'Services',
    component: Services
  },
  {
    path: '/banners',
    name: 'Banners',
    component: Banners
  },
  {
    path: '/cities',
    name: 'Cities',
    component: Cities
  },
  {
    path: '/workers',
    component: Workers,
    children: [
      { path: '', component: WorkersDefault, name: 'Workers' },
      { path: ':wid', component: Worker, name: 'Worker' }
    ]
  },
  {
    path: '/operators',
    name: 'Operators',
    component: Operators
  },
  {
    path: '/operatorsAccount',
    name: 'OperatorsAccount',
    component: OperatorsAccount
  },
  {
    path: '/login',
    name: 'Login',
    component: Login
  },
  {
    path: '/haier_test',
    name: 'HaierTest',
    component: HaierTest
  }
]

routes = [...routes, ...universities]

// mode: 'history',
const router = new Router({
  routes: routes
})

router.changeQuery = function(query, callback) {
  var currentRoute = this.currentRoute
  query = Object.assign({}, currentRoute.query, query)
  let data = { query: query, path: currentRoute.path }
  router.push(data, (e) => {
    if (typeof callback === 'function') {
      callback(e)
    }
  })
}

export default router
