export default {
  toBase64(file, callback) {
    let reader = new FileReader()
    reader.onloadend = () => {
      callback(reader.result)
    }
    reader.readAsDataURL(file)
  }
}
