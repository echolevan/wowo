<template>
  <md-layout md-gutter class='info-title'>
    <md-layout>
      <md-whiteframe md-elevation="1">
        机器12总数：
        <strong>{{washerCount}} 台</strong>
      </md-whiteframe>
    </md-layout>
    <md-layout>
      <md-whiteframe md-elevation="1">
        运行天数：
        <strong>{{totalDays}} 天</strong>
      </md-whiteframe>
    </md-layout>
    <md-layout>
      <md-whiteframe md-elevation="1">
        订单总数：
        <strong>{{totalOrders}} 单</strong>
      </md-whiteframe>
    </md-layout>
    <md-layout>
      <md-whiteframe md-elevation="1">
        收入：
        <strong>{{totalMoney}} 元</strong>
      </md-whiteframe>
    </md-layout>
    <md-layout>
      <md-whiteframe md-elevation="1">
        单机日均：
        <strong>{{orderPerDayAndWasher}}单</strong>
      </md-whiteframe>
    </md-layout>
    <md-layout>
      <md-whiteframe md-elevation="1">
        活跃用户：
        <strong>{{activeUsers}} 人</strong>
      </md-whiteframe>
    </md-layout>
    <md-layout style='padding-right:5px'>
      <md-whiteframe md-elevation="1">
        人均订单数：
        <strong>{{(totalOrders/activeUsers).toFixed(2)}}</strong>
      </md-whiteframe>
    </md-layout>
  </md-layout>
</template>

<script>
export default {
  props: {
  }
  data () {
    return {}
  }
}
  </script>

<style lang="sass">
</style>

