import Vue from 'vue'
import Vuex from 'vuex'
import moment from 'moment'

Vue.use(Vuex)

const originalDate = '2017-05-13'
const dateFormat = 'YYYY-MM-DD HH:mm:ss'

const store = new Vuex.Store({
  state: {
    orders: [],
    orderCount: 0,
    washers: [],
    university: {},
    orderStats: {},
    spinnerCount: 0,
    uniActiveTab: null,
    showSpinner: false,
    totalOrderCountByWasher: [],
    todayOrderCountByWasher: [],
    zeroIdUniversity: {
      id: 0,
      name: '所有学校'
    },
    alert: {
      message: '',
      duration: 6000,
      type: 'default',
      position: 'bottom center'
    },
    endTime: {
      time: moment().format(dateFormat)
    },
    startTime: {
      time: moment(originalDate, dateFormat).format(dateFormat)
    },
    orderStatus: ['已下单', '已支付', '已开始', '已完成', '已取消'],
    weekdayNames: ['周一', '周二', '周三', '周四', '周五', '周六', '周日'],
    orderAttributes: {
      number: '订单号',
      user_id: '用户ID',
      name: '用户姓名',
      service_name: '服务类型',
      service_price: '价格',
      state: '订单状态'
    }
  },
  getters: {
    washerIds: state => {
      return state.washers.map(washer => { return washer.id })
    },
    orderByService: state => {
      return state.orderStats.countGroupByService || []
    },
    orderByHourWeekend: state => {
      return state.orderStats.countGroupByHourWeekend || []
    },
    orderByHourWorkday: state => {
      return state.orderStats.countGroupByHourWeekday || []
    },
    orderByHour: state => {
      return state.orderStats.countGroupByHour || []
    },
    orderCountByWasherStats: state => {
      let stats = {}
      for (let item of state.totalOrderCountByWasher) {
        stats[item.washer_id] = {
          average: item.average,
          total: item.count,
          days: item.days
        }
      }
      for (let item of state.todayOrderCountByWasher) {
        stats[item.washer_id]['todayCount'] = item.count
      }
      return stats
    },
    orderByWeekday: state => {
      let byWeekday = state.orderStats.countGroupByWeekday
      if (byWeekday) {
        return byWeekday.map((item) => {
          return { name: state.weekdayNames[item.week], value: item.count }
        })
      } else {
        return []
      }
    },
    orderByWasher: state => {
      let result = {
        data: [],
        xAxisData: []
      }
      let dataByWasher = state.orderStats.countGroupByWasher
      if (dataByWasher) {
        result['data'] = [dataByWasher.map((item) => { return item.count })]
        result['xAxisData'] = dataByWasher.map((item) => {
          return item.washer_name
        })
      }
      return result
    },
    orderByPay: state => {
      let result = {
        data: [],
        xAxisData: []
      }
      let dataByPay = state.orderStats.countGroupByPay
      if (dataByPay) {
        result['data']['amount'] = [dataByPay.map((item) => { return item.amount })]
        result['data']['count'] = [dataByPay.map((item) => { return item.count })]
        result['xAxisData'] = dataByPay.map((item) => {
          return item.day + state.weekdayNames[item.weekday]
        })
      }
      return result
    },
    orderByUser: state => {
      let result = {
        data: [],
        xAxisData: []
      }
      let dataByUser = state.orderStats.countGroupByUser
      if (dataByUser) {
        result['data'] = [dataByUser.map((item) => { return item.value })]
        result['xAxisData'] = dataByUser.map((item) => {
          return item.date + state.weekdayNames[item.weekday]
        })
      }
      return result
    },
    orderByUserProvince: state => {
      return state.orderStats.countGroupByUserProvince || []
    },
    orderByDate: state => {
      let result = {
        data: [],
        xAxisData: []
      }
      let dataByDate = state.orderStats.countGroupByDate

      if (dataByDate) {
        result['data'] = [dataByDate.map((item) => { return item.count })]
        result['xAxisData'] = dataByDate.map((item) => {
          return item.day + state.weekdayNames[item.weekday]
        })
      }
      return result
    },
    orderByPayType: state => {
      return state.orderStats.countGroupByPayType || []
    },
    orderSummary: state => {
      let stats = state.orderStats
      console.log(stats)
      if (stats.total) {
        let totalOrder = stats.total
        let totalDays = stats.countGroupByDate.length
        let payTotal = stats.payTotal
        let userPay = stats.userPay
        let beenUse = stats.beenUse
        let balanceAmount = stats.balanceAmount
        let totalAmount = stats.totalAmount
        let washerCount = stats.countWasher
        let per = Math.round(stats.countPerWasherPerDay * 100) / 100
        return {
          '账户总额': totalAmount,
          '已消费': beenUse,
          '账户余额': balanceAmount,
          '实际充值': payTotal,
          '实际消费': userPay,
          '设备总数': washerCount,
          '运行天数': totalDays,
          '订单总数': totalOrder,
          '单机日均': per,
          '活跃用户': stats.activeUsers,
          '人均订单数': (totalOrder / stats.activeUsers).toFixed(2)
        }
      } else {
        return {
          '机器总数': 0,
          '运行天数': 0,
          '订单总数': 0,
          '收入': 0,
          '单机日均': 0,
          '活跃用户': 0,
          '人均订单数': 0,
          '充值总额': 0
        }
      }
    }
  },
  mutations: {
    setOrders(state, orders) {
      state.orders = orders
    },
    setOrderCount(state, count) {
      state.orderCount = count
    },
    setStartTime(state, time) {
      state.startTime = { time: time }
    },
    setEndTime(state, time) {
      state.endTime = { time: time }
    },
    setWashers(state, washers) {
      state.washers = washers
    },
    setUniversity(state, uni) {
      state.university = uni
    },
    showSpinner(state) {
      state.spinnerCount ++
      state.showSpinner = true
    },
    hideSpinner(state) {
      state.spinnerCount --
      if (state.spinnerCount <= 0) {
        state.showSpinner = false
      }
    },
    uniTabChanged(state, tab) {
      state.uniActiveTab = tab
    },
    changeAlert(state, alert) {
      Object.keys(alert).forEach((key) => (alert[key] == null) && delete alert[key])
      Object.assign(state.alert, alert)
    },
    setOrderStats(state, stats) {
      state.orderStats = stats
    },
    setTotalOrderCountByWasher(state, count) {
      state.totalOrderCountByWasher = count
    },
    setTodayOrderCountByWasher(state, count) {
      state.todayOrderCountByWasher = count
    }
  },
  actions: {
    async getWashers({ commit }, params = {}) {
      let res = await Vue.http.get('washers', { params: params })
      commit('setWashers', res.body)
    },
    async getOrderStats({ commit }, params = {}) {
      // console.log(params)
      let res = await Vue.http.get('orders/stats', {params: params})
      commit('setOrderStats', res.body)
    },
    async getOrders({ commit, state }, params = {}) {
      let defaultParams = {
        page: 1,
        size: 10,
        order_by_name: 'id',
        order_by_type: 'desc'
      }
      params = Object.assign(defaultParams, params)
      let res = await Vue.http.get('orders', { params: params })
      commit('setOrders', res.body.orders)
      commit('setOrderCount', res.body.count)
    },
    async getOrderCountByWasher({ commit }, uid) {
      let url = `universities/${uid}/order_stats_by_washer`
      let res = await Vue.http.get(url)
      let counts = res.body
      commit('setTotalOrderCountByWasher', counts.totalCount)
      commit('setTodayOrderCountByWasher', counts.todayCount)
    },
    async getUniversity({ commit, state }, id) {
      if (parseInt(id)) {
        let res = await Vue.resource('universities{/id}').get({id: id})
        commit('setUniversity', res.body)
      } else {
        commit('setUniversity', state.zeroIdUniversity)
      }
    },
    error({ commit }, message, position, duration) {
      commit('changeAlert', {
        type: 'error',
        message: message,
        position: position,
        duration: duration
      })
    },
    success({ commit }, message, position, duration) {
      commit('changeAlert', {
        type: 'success',
        message: message,
        position: position,
        duration: duration
      })
    }
  }
})
export default store
