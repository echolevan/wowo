<template>
  <div>
    <h1>UW</h1>
  </div>
</template>

<script>

export default {
  mounted() {
    this.$store.commit('uniTabChanged', 3)
  },
  methods: {
    click() {}
  }
}
</script>
