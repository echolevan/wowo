<template>
  <div>
    <div class='uni-tool-list'>
      <div class='md-tabs md-theme-default md-dynamic-height'>
        <div class='md-whiteframe md-tabs-navigation md-whiteframe-0dp md-has-label'>
          <md-layout md-gutter>
            <md-layout md-flex="20">
              <md-menu>
                <md-button md-menu-trigger class='select-city'>{{selectedOperator}}<md-icon>arrow_drop_down</md-icon></md-button>
                <md-menu-content>
                  <md-menu-item v-for='v in operators' :key='v.id' @click.native="opSelected(v.id, v.name)">{{v.name}}</md-menu-item>
                </md-menu-content>
              </md-menu>
            </md-layout>

            <md-layout md-flex="50" class='tool-middle'>
              <form novalidate @submit.stop.prevent="searchByName()">
                <input class='search-by-name' autofocus='autofocus' placeholder="输入运营商名称搜索..." v-model='operatorName'>
              </form>
            </md-layout>

            <router-link to="/operators" :class="{active: $route.name === 'Operators'}">
            <md-button class="md-primary" style="color: #ffffff;font-weight: bold">返回运营商</md-button>
            </router-link>

            <md-layout md-flex="20">
              <div class='tool-icons'>
                <md-button @click.native="openDialog('add-uni-form')" class="add-uni md-icon-button md-raised md-warn" id='add-uni'>
                  <md-icon>add</md-icon>
                  <md-tooltip md-direction="left">点击添加运营商员工帐号</md-tooltip>
                </md-button>
              </div>
            </md-layout>
          </md-layout>
        </div>
      </div>
    </div>
    <md-dialog md-open-from="#add-uni" md-close-to="#add-uni" ref="add-uni-form" class='add-uni'>
      <md-dialog-title>添加运营商员工帐号</md-dialog-title>
      <md-dialog-content>
        <form novalidate @submit.stop.prevent="submit">
          <md-input-container>
            <label>选择运营商</label>
            <md-select v-model="add_operator.selectop">
              <md-option v-for="v in operators" :value="v.id">{{v.name}}</md-option>
            </md-select>
          </md-input-container>
          <md-input-container>
            <label>城市</label>
            <md-input v-model="add_operator.city"></md-input>
          </md-input-container>
          <md-input-container>
            <label>用户昵称</label>
            <md-input v-model="add_operator.nickname"></md-input>
          </md-input-container>
          <md-input-container>
            <label>电话</label>
            <md-input v-model="add_operator.phone"></md-input>
          </md-input-container>
          <md-input-container>
            <label>邮箱</label>
            <md-input v-model="add_operator.email"></md-input>
          </md-input-container>
          <md-input-container>
            <label>密码</label>
            <md-input v-model="add_operator.password"></md-input>
          </md-input-container>
        </form>
      </md-dialog-content>
      <md-dialog-actions>
        <md-button class="md-primary" @click.native="cancelDialog('add-uni-form')">取消</md-button>
        <md-button class="md-primary" @click.native="submitDialog('add-uni-form')" :disabled="disableSubmit">确认提交</md-button>
      </md-dialog-actions>
    </md-dialog>
    <div class='uni-list'>
      <md-table>
        <md-table-header>
          <md-table-row>
            <md-table-head class='center'>运营商名称</md-table-head>
            <md-table-head class='center'>城市</md-table-head>
            <md-table-head class='center'>用户昵称</md-table-head>
            <md-table-head class='center'>电话</md-table-head>
            <md-table-head class='center'>邮箱</md-table-head>
            <md-table-head class='center'>管理</md-table-head>
          </md-table-row>
        </md-table-header>
        <md-table-body>
          <md-table-row v-for="(p,k) in accounts" :key="p.id">
            <md-table-cell>{{p.operator.name}}</md-table-cell>
            <md-table-cell>{{p.city}}</md-table-cell>
            <md-table-cell>{{p.nickname}}</md-table-cell>
            <md-table-cell>{{p.phone}}</md-table-cell>
            <md-table-cell>{{p.email}}</md-table-cell>
            <md-table-cell>
              <md-button style="width:50px" @click.native="openEdit('add-uni-form', p)">编辑</md-button>
              <md-button style="width:50px" @click.native="operator_delete(p.id,k)">删除</md-button>
            </md-table-cell>
          </md-table-row>
        </md-table-body>
      </md-table>
    </div>
  </div>
</template>

<script>

export default {
  data() {
    return {
      operators: [],
      add_operator: [],
      operatorName: null,
      accounts: [],
      disableSubmit: false,
      selectedOperator: '全部运营商'
    }
  },
  mounted() {
    this.getoperators()
    this.getaccount()
  },
  methods: {
    getaccount(params) {
      var uni = this.$resource('operators_account?city={city}&name={name}')
      uni.get(params).then(res => {
        console.log(res)
        this.accounts = res.body
      })
    },

    getoperators() {
      this.$resource('getAllOperators').get().then(res => {
        this.operators = res.body
        this.operators.unshift({
          id: 0,
          name: '全部运营商'
        })
      })
    },
    opSelected(city, name) {
      this.selectedOperator = name
      this.getaccount({city: city})
    },
    searchByName() {
      this.getOperators({name: this.operatorName})
    },
    openDialog(ref) {
      this.$refs[ref].open()
    },
    operator_delete(id, k) {
      this.$resource(`operators_delete/${id}`).delete().then(res => {
        if (res.data.sta === 0) {
          this.accounts.splice(k, 1)
        }
      })
    },
    openEdit(ref, operator) {
      this.add_operator = operator
      this.add_operator.selectop = operator.operator.id
      this.disableSubmit = false
      this.$refs[ref].open()
    },
    cancelDialog(ref) {
      this.add_operator = null
      this.$refs[ref].close()
    },
    async submitDialog(ref) {
      this.disableSubmit = true
      try {
        if (this.add_operator.id) {
          await this.$http.put(`update_operators/${this.add_operator.id}`, this.add_operator)
          this.$store.dispatch('success', '运营商员工更新成功')
        } else {
          this.$http.post('add_operators', {selectop: this.add_operator.selectop, city: this.add_operator.city, nickname: this.add_operator.nickname, phone: this.add_operator.phone, email: this.add_operator.email, password: this.add_operator.password}).then(res => {
            if (res.data.sta === 1) {
              this.accounts.unshift(res.data.operator)
              this.$store.dispatch('success', '运营商员工添加成功')
            }
          }).catch(error => {
            console.log(error)
            this.$store.dispatch('error', '参数不能为空')
          })
        }
        this.$refs[ref].close()
        this.disableSubmit = false
      } catch (e) {
        this.$store.dispatch('error', e.body.message)
        this.disableSubmit = false
      }
    }
  }
}
</script>

<style lang="scss">
.uni-list {
  padding: 20px;
  .md-table {
    background: #fff;
    .md-table-head-container {
      height: 40px;
      padding: 6px 0px;
    }
  }
}
.md-menu-content.md-direction-bottom-right.md-active {
  .md-list-item-container.md-button {
    font-size: 14px !important;
  }
}
</style>

<style lang="scss" scoped>
.md-button.md-fab .md-icon, .md-button.md-icon-button .md-icon {
  top: 0px;
}
.md-table .md-table-head {
  font-size: 14px;
}
.uni-list {
  padding: 20px;
  .md-table {
    background: #fff;
  }
}
.uni-tool-list {
  .tool-icons {
    width: 100%;
    padding: 4px;
    margin-right: 10px;
    text-align: right;
  }
  .tool-middle {
    form {
      margin: auto;
      margin-top: 7px;
    }
    .search-by-name {
      outline: none;
      border: 0px;
      text-align: center;
      height: 35px;
      width: 500px;
      font-size: 14px;
    }
  }
}
.add-uni {
  cursor: pointer;
  margin-top: 10px;
}
.select-city {
  color: #fff;
  text-align: left;
  font-weight: bold;
  background: #29B6F6 !important;
  margin-left: 20px;
  .md-icon {
    margin-top: -8px;
  }
}
.uni-name {
  margin: auto;
  color: #000 !important;
}
</style>
