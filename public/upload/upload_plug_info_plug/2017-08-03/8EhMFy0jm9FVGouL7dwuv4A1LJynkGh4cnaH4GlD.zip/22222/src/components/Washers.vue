<template>
  <div class='bui-list'>
    <div class='bui-tool-list'>
      <md-layout md-gutter>
        <md-layout md-flex="20">
          <md-menu>
            <md-button md-menu-trigger class='select-city'>{{selectedCity}}<md-icon>arrow_drop_down</md-icon></md-button>
            <md-menu-content>
              <md-menu-item v-for='city in cities' :key='city.id' @click.native="citySelected(city)">{{city.name}}</md-menu-item>
            </md-menu-content>
          </md-menu>
        </md-layout>
        <md-layout md-flex="20">
          <md-menu>
            <md-button md-menu-trigger class='select-uni'>{{selectedUni.name}}<md-icon>arrow_drop_down</md-icon></md-button>
            <md-menu-content>
              <md-menu-item v-for='uni in universities' :key='uni.id' @click.native="uniSelected(uni)">{{uni.name}}</md-menu-item>
            </md-menu-content>
          </md-menu>
        </md-layout>
        <md-layout md-flex="20">
          <md-menu>
            <md-button md-menu-trigger class='select-uni'>{{selectedBuilding.name}}<md-icon>arrow_drop_down</md-icon></md-button>
            <md-menu-content>
              <md-menu-item v-for='bui in buildings' :key='bui.id' @click.native="buiSelected(bui)">{{bui.name}}</md-menu-item>
            </md-menu-content>
          </md-menu>
        </md-layout>
        <md-layout md-flex="40" class='tool-middle'>
        </md-layout>
        <!-- <md-layout md-flex="20"> -->
        <!--   <div class='tool-icons'> -->
        <!--     <md-button @click.native="openDialog('add-bui-form')" class="add-bui md-icon-button md-raised md-warn" id='add-bui'> -->
        <!--       <md-icon>add</md-icon> -->
        <!--       <md-tooltip md-direction="top">添加宿舍楼</md-tooltip> -->
        <!--     </md-button> -->
        <!--   </div> -->
        <!-- </md-layout> -->
      </md-layout>
    </div>
    <md-dialog md-open-from="#add-bui" md-close-to="#add-bui" ref="add-bui-form" class='add-bui'>
      <md-dialog-title>添加宿舍楼</md-dialog-title>
      <md-dialog-content>
        <form novalidate @submit.stop.prevent="submit">
          <md-input-container>
            <md-select name="name" id="name" v-model="building.org_id">
              <md-option v-for="uni in allUniversities" :key="uni.id" :value='uni.id'>{{uni.name}}</md-option>
            </md-select>
          </md-input-container>
          <md-input-container>
            <label>宿舍楼名称</label>
            <md-input v-model="building.name"></md-input>
          </md-input-container>
        </form>
      </md-dialog-content>
      <md-dialog-actions>
        <md-button class="md-primary" @click.native="cancelDialog('add-bui-form')">取消</md-button>
        <md-button class="md-primary" @click.native="submitDialog('add-bui-form')" :disabled="disableSubmit">确认提交</md-button>
      </md-dialog-actions>
    </md-dialog>
    <div v-if='!washers.length' style='padding-top: 20px'>
      <h3>请选择学校和宿舍楼信息来筛选洗衣机</h3>
      <br />
    </div>
    <md-table v-if='washers.length'>
      <md-table-header>
        <md-table-row>
          <md-table-head class='center'>洗衣机名字</md-table-head>
          <md-table-head class='center'>洗衣机编号</md-table-head>
        </md-table-row>
      </md-table-header>
      <md-table-body>
        <md-table-row v-for="washer in washers" :key="washer.id">
          <md-table-cell>{{washer.name}}</md-table-cell>
          <md-table-cell>{{washer.number}}</md-table-cell>
        </md-table-row>
      </md-table-body>
    </md-table>
  </div>
</template>

<script>

export default {
  data() {
    return {
      school: {},
      building: {},
      buildings: [],
      disableSubmit: false,
      cities: [],
      washers: [],
      universities: [],
      allUniversities: [],
      selectedCity: '城市',
      selectedUni: {name: '学校'},
      selectedBuilding: {name: '宿舍楼'}
    }
  },
  mounted() {
    this.getCities()
    this.getUniversities()
    this.getWashers()
  },
  methods: {
    getCities() {
      this.$resource('cities').get().then(res => {
        this.cities = res.body
        this.cities.unshift({
          id: 0,
          name: '全部城市'
        })
      })
    },
    getUniversities(params) {
      var uni = this.$resource('universities?city={city}&name={name}')
      uni.get(params).then(res => {
        this.universities = res.body
      })
    },
    getSchool(id) {
      var resource = this.$resource('universities{/id}')
      resource.get({id: id}).then(res => {
        this.school = res.body
        this.selectedUni = this.school
        this.selectedCity = this.school.city
        this.getUniversities({city: this.school.city})
      })
    },
    getBuildings(id) {
      var resource = this.$resource('universities{/id}/buildings')
      resource.get({id: id}).then(res => {
        this.buildings = res.body
      })
    },
    citySelected(city) {
      this.selectedCity = city.name
      this.getUniversities({city: city.name})
    },
    getAllUniversities() {
      var uni = this.$resource('universities?city={city}&name={name}')
      uni.get().then(res => {
        this.allUniversities = res.body
      })
    },
    uniSelected(uni) {
      this.selectedUni = uni
      this.getBuildings(uni.id)
      this.getWashers({org_id: uni.id})
    },
    buiSelected(bui) {
      this.selectedBuilding = bui
      this.getWashers({building_id: bui.id})
    },
    getWashers(params) {
      var uni = this.$resource('washers?org_id={org_id}&building_id={building_id}')
      uni.get(params).then(res => {
        this.washers = res.body
      })
    }
  }
}
</script>

<style lang="scss" scoped>
.md-table .md-table-head {
  font-size: 16px;
}
.bui-list {
  background: #fff;
}
.bui-tool-list {
  padding: 3px 10px;
  border-bottom: 1px solid #ddd;
  height: 56px;
  .tool-icons {
    width: 100%;
    padding: 4px;
    text-align: right;
  }
}
.add-bui {
  cursor: pointer;
  margin-top: 10px;
}
.bui-name {
  margin: auto;
  color: #000 !important;
}
.select-city, .select-uni {
  width: 160px;
  text-align: left;
  border: 1px solid #ddd;
}
</style>
