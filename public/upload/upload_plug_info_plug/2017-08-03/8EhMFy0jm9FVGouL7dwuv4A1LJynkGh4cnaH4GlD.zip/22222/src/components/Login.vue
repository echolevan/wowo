<template>
  <div class='login-form'>
    <md-layout md-gutter>
      <md-layout md-flex="30" md-flex-offset="35">
        <form novalidate @submit.stop.prevent="submit">
          <div class='title'> <p><strong>登录轻氧智能洗衣</strong> </p></div>
          <div class='inputs'>
            <md-input-container>
              <md-icon> email </md-icon>
              <label>邮箱</label>
              <md-input type="text" v-model="user.email"></md-input>
            </md-input-container>

            <md-input-container md-has-password>
              <md-icon> local_parking </md-icon>
              <label>密码</label>
              <md-input type="password" v-model="user.password"></md-input>
            </md-input-container>
            <br />
            <md-button type="submit" class="md-raised md-primary">登录</md-button>
          </div>
        </form>
        </md-layout>
    </md-layout>
  </div>
</template>

<script>
import router from '../router'

export default {
  data() {
    return {
      user: {}
    }
  },
  methods: {
    async submit() {
      try {
        let res = await this.$auth.login(this.user)
        this.$user.tokens = res.body
        this.getCurrentUser()
      } catch (e) {
        this.$store.dispatch('error', '登录失败，用户名或密码错误。', 'top center')
      }
    },
    getCurrentUser() {
      this.$resource('users/me').get().then(res => {
        localStorage.setItem('current_user', JSON.stringify(res.body))
        router.push({ path: '/universities/0' })
        this.$store.dispatch('success', '登录成功')
      })
    }
  }
}
</script>

<style lang="scss">
.login-form {
  .md-layout {
    .md-layout {
      form {
        background: #fff;
        margin-top: 100px;
        width: 100%;
        font-size: 20px;
        border-radius: 4px;
        box-shadow: 2px 2px 5px 1px rgba(0, 0, 0, 0.2);
        .title {
          height: 80px;
          width: 100%;
          font-size: 20px;
          background: #03a9f4;
          color: white;
          line-height: 150%;
          border-radius: 4px 4px 0 0;
          padding-top: 25px;
          box-shadow: 0 2px 5px 1px rgba(0, 0, 0, 0.2);
          p {
            margin: 0px;
          }
        }
        .inputs {
          padding: 40px 30px 60px 30px;
        }
      }
    }
  }
}
</style>
