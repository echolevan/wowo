<template>
  <div class='full-height'>
    <md-layout md-gutter class='content-top-header'>
      <md-layout md-flex="70">
        <div class='md-tabs md-theme-default md-dynamic-height'>
          <div class='md-tabs-navigation md-has-label'>
            <md-layout md-gutter>

              <md-layout md-flex="30">
                <md-menu class='select-uni-menu'>
                  <md-button md-menu-trigger class='select-uni'>{{university.name}}<md-icon>arrow_drop_down</md-icon></md-button>
                  <md-menu-content>
                    <md-menu-item v-for='uni in universities' :key='uni.id' @click.native="uniSelected(uni)">{{uni.name}}</md-menu-item>
                  </md-menu-content>
                </md-menu>
              </md-layout>


              <md-layout md-flex="70">
                <transition name="slide" enter-active-class="slideInRight" leave-active-class="slideOutRight">
                  <md-layout md-gutter v-if="activeTab !== null && activeTab <= 1">
                    <md-layout md-flex="20">
                      <md-menu>
                        <md-button md-menu-trigger class='select-date-condition'>{{dateConditions[currentConditionIndex]}}<md-icon>arrow_drop_down</md-icon></md-button>
                        <md-menu-content>
                          <md-menu-item v-for='(con, index) in dateConditions' :key='index' @click.native="conSelected(index)">{{con}}</md-menu-item>
                        </md-menu-content>
                      </md-menu>
                    </md-layout>
                    <md-layout md-flex="80">
                      <div class='date-input'>
                        <strong>From</strong>
                        <datepicker :date="startTime" :limit="startLimit" :option="startOption" @change="startTimeChange"></datepicker>
                        <strong>To</strong>
                        <datepicker :date="endTime" :limit="endLimit" :option="endOption" @change="endTimeChange"></datepicker>
                      </div>
                    </md-layout>
                  </md-layout>
                </transition>
              </md-layout>
            </md-layout>
          </div>
        </div>
      </md-layout>
      <md-layout md-flex="30">
        <md-tabs md-right @change="tabChanged" class='uni-tabs'>
          <md-tab id="uni-order-stats" md-label="首页统计" :md-active="activeTab === 0">
          </md-tab>
          <md-tab id="uni-order-list" md-label="订单列表" :md-active="activeTab === 1">
          </md-tab>
          <md-tab id="uni-buildings" md-label="设备管理" :md-active="activeTab === 2">
          </md-tab>
          <!-- <md-tab id="uni-washers" md-label="设备管理" :md-active="activeTab === 3" style='margin-right: 25px;'> -->
          <!-- </md-tab> -->
        </md-tabs>
      </md-layout>
    </md-layout>
    <div class='tabs-page-content'>
      <router-view></router-view>
    </div>
  </div>
</template>

<script>
  import router from '../../router'
  import moment from 'moment'
  import dOption from '../../datepicker_options'
  import { mapState } from 'vuex'

  var dateFormat = 'YYYY-MM-DD HH:mm:ss'
  var originalDate = '2017-05-13'
  Object.assign(dOption, { format: dateFormat })

  function myDate(date) {
    return moment(date, dateFormat)
  }

  export default {
    computed: {
      ...mapState({activeTab: 'uniActiveTab'}),
      ...mapState(['university', 'startTime', 'endTime'])
    },
    data() {
      return {
        universities: [],
        currentConditionIndex: 0,
        startLimit: [{
          type: 'fromto',
          to: moment().format(dateFormat),
          from: moment(originalDate, dateFormat).subtract(1, 'day').format(dateFormat)
        }],
        endLimit: [{
          type: 'fromto',
          from: originalDate,
          to: moment().format(dateFormat)
        }],
        startOption: Object.assign({}, dOption, {
          placeholder: '开始时间'
        }),
        endOption: Object.assign({}, dOption, {
          placeholder: '结束时间'
        }),
        tabs: [
          'UniversityOrderStats',
          'UniversityOrderList',
          'UniversityBuildings',
          'UniversityWashers'
        ],
        dateConditions: [
          '选择日期', '过去一天', '过去两天', '过去三天', '过去一周', '过去两周', '过去一个月', '过去三个月', '过去半年', '过去一年'
        ],
        dateConditionBeginnings: [
          [moment().diff(moment(originalDate, dateFormat), 'days'), 'days'],
          [1, 'day'], [2, 'days'], [3, 'days'], [1, 'week'], [2, 'weeks'], [1, 'month'], [3, 'months'], [6, 'months'], [1, 'year']
        ]
      }
    },
    mounted() {
      let uid = this.$route.params.uid
      this.$store.dispatch('getUniversity', uid)
      this.getUniversities()
    },
    methods: {
      setEndTime(time) {
        this.$store.commit('setEndTime', time)
      },
      setStartTime(time) {
        this.$store.commit('setStartTime', time)
      },
      endTimeChange(date) {
        date = myDate(date).endOf('day').format(dateFormat)
        this.$store.commit('setEndTime', date)
        this.startLimit = [{
          type: 'fromto',
          to: moment(date, dateFormat).add(1, 'day').format(dateFormat),
          from: moment(originalDate, dateFormat).subtract(1, 'day').format(dateFormat)
        }]
      },
      startTimeChange(date) {
        this.setStartTime(date)
        this.endLimit = [{
          type: 'fromto',
          from: moment(date, dateFormat).subtract(1, 'day').format(dateFormat),
          to: moment().format(dateFormat)
        }]
      },
      changeDateAfterSelected(index) {
        this.currentConditionIndex = index
        let args = this.dateConditionBeginnings[index]
        this.setEndTime(moment().format(dateFormat))
        let start = moment().subtract(...args)
        if (index === 0) {
          start = start.startOf('day')
        }
        this.setStartTime(start.format(dateFormat))
      },
      conSelected(index) {
        this.changeDateAfterSelected(index)
      },
      uniSelected(uni) {
        this.$store.commit('setUniversity', uni)
      },
      getUniversities() {
        var uni = this.$resource('universities')
        uni.get().then((res) => {
          this.universities = res.body
          this.universities.unshift(this.$store.state.zeroIdUniversity)
        })
      },
      tabChanged(index) {
        if (this.activeTab === null) {
          let tab = this.tabs.indexOf(this.$router.currentRoute.name)
          this.$store.commit('uniTabChanged', tab)
        } else {
          if (this.activeTab !== index) {
            this.$store.commit('uniTabChanged', index)
            router.push({ name: this.tabs[index] })
          }
        }
      }
    }
  }
</script>

<style lang="scss">
  .uni-tabs .md-tabs-navigation {
    padding-right: 15px;
  }
  .md-tabs-content {
    display: none;
  }
  .md-tab-header-container span {
    color: #fff;
    font-weight: bold;
  }
  .tabs-title {
    font-size: 18px;
    color: #fff;
    margin-left: 40px;
  }
  .md-menu-content.md-direction-bottom-right.md-active {
    margin-top: -28px !important;
    margin-left: -1px;
  }
  .date-input {
    width: 100%;
    text-align: left;
    margin-top: 6px;
    color: #fff;
    font-weight: bold;
    .cov-vue-date {
      width: 40%;
      input.cov-datepicker {
        width: 100%;
        font-weight: bold;
      }
    }
  }
</style>

<style lang="scss" scoped>
  .md-tabs .md-tabs-navigation {
    z-index: inherit;
  }
  .md-button.select-uni, .md-button.select-date-condition {
    color: #fff;
    text-align: left;
    font-weight: bold;
    background: #29B6F6 !important;
    margin-left: 25px;
    font-size: 14px !important;
    .md-icon {
      margin-top: -8px;
    }
  }
  .md-button.select-date-condition {
    margin-left: 0px;
  }
  .tabs-page-content {
    padding-top: 50px;
  }
</style>
