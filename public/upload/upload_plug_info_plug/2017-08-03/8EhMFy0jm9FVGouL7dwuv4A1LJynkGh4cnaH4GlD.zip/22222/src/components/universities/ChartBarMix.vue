<template>
  <md-whiteframe md-elevation="1">
    <figure :style="figureStyle">
      <chart :options="options" auto-resize :style="chartStyle" theme="macarons"></chart>
    </figure>
  </md-whiteframe>
</template>

<script>
  export default {
    props: {
      data: {
        type: Array,
        required: true
      },
      xAxisData: {
        type: Array,
        required: true
      },
      name: String,
      title: {
        type: String,
        required: true
      },
      chartStyle: {
        type: Object
      },
      figureStyle: {
        type: Object
      }
    },
    name: 'ChartBar',
    data() {
      return {
        options: {
          tooltip: {
            trigger: 'axis',
            axisPointer: {
              type: 'cross'
            }
          },
          toolbox: {
            show: true,
            feature: {
              saveAsImage: {}
            }
          },
          legend: {
            data: ['充值金额', '充值次数']
          },
          xAxis: {
            data: []
          },
          yAxis: [
            {
              type: 'value',
              name: '次数',
              axisLabel: {
                formatter: '{value}次'
              }
            },
            {
              type: 'value',
              name: '金额',
              axisLabel: {
                formatter: '{value}元'
              }
            }
          ],
          series: [
            {
              name: '充值金额1',
              type: 'bar',
              data: [],
              markPoint: {
                data: [
                  {type: 'max', name: '最大值'},
                  {type: 'min', name: '最小值'}
                ]
              },
              markLine: {
                data: [
                  {type: 'average', name: '平均值'}
                ]
              }
            },
            {
              name: '充值次数',
              type: 'line',
              data: [],
              yAxisIndex: 1,
              markPoint: {
                data: [
                  {type: 'max', name: '最大值'},
                  {type: 'min', name: '最小值'}
                ]
              },
              markLine: {
                data: [
                  {type: 'average', name: '平均值'}
                ]
              }
            }
          ]
        }
      }
    },
    watch: {
      data(val) {
        this.setData(val)
      },
      xAxisData(val) {
        this.options.xAxis.data = val
      }
    },
    methods: {
      setData(data) {
        if (!Array.isArray(data[0])) {
          data = [data]
        }
        this.options.series = data.map((item) => {
          return [
            {
              name: '充值次数',
              type: 'line',
              data: item.count[0],
              itemStyle: {
                normal: {
                  color: '#b6a2de'
                }
              },
              markPoint: {
                data: [
                  {type: 'max', name: '最大值'},
                  {type: 'min', name: '最小值'}
                ]
              },
              markLine: {
                data: [
                  {type: 'average', name: '平均次数'}
                ]
              }
            },
            {
              name: '充值金额',
              type: 'bar',
              data: item.amount[0],
              yAxisIndex: 1,
              itemStyle: {
                normal: {
                  color: '#2ec7c9'
                }
              },
              markPoint: {
                data: [
                  {type: 'max', name: '最大值'},
                  {type: 'min', name: '最小值'}
                ]
              },
              markLine: {
                data: [
                  {type: 'average', name: '平均金额'}
                ]
              }
            }
          ]
        })
        this.options.series = this.options.series[0]
      }
    }
  }
</script>

<style lang="scss" scoped>
  .md-whiteframe {
    cursor: pointer;
    &:hover {
      border: 1px solid #03A9F4;
      font-weight: bold;
    }
  }
  figure {
    width: 100%;
    margin: 0;
  }
  .echarts {
    height: 220px;
    width: 100%;
  }
</style>
