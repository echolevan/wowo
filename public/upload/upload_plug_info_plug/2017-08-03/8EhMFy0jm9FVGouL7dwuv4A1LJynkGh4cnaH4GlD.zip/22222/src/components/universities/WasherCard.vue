<template>
    <md-card class="washer-card">
      <md-card-area md-inset>
        <md-card-header>
          <h2 class="md-title"><small>{{washer.floor}}层</small>-{{washer.name}}</h2>
          <div class="md-subhead">
            <span>编号：</span>
            <span>{{washer.number}}</span>
          </div>
          <div class="md-subhead">
            <span>IMEI码：</span>
            <span>{{washer.device_id}}</span>
          </div>
        </md-card-header>
        <md-card-content>
          <span class="md-body-2">今天已完成：{{stats.todayCount}} 单</span>
          <span class="md-body-2">本机运行时间：{{stats.days}} 天</span>
          <span class="md-body-2">本机总订单量：{{stats.total}} 单</span>
          <span class="md-body-2">本机日均订单：{{parseFloat(stats.average).toFixed(2)}} 单</span>
        </md-card-content>
      </md-card-area>

      <md-card-content>
        <h3 class="md-subheading">当前状态：{{washerStatus[washer.status]}}</h3>
        <h3 class="md-subheading">在线：{{online[washer.is_online]}}</h3>
        <h3 class="md-subheading">最后错误：{{washer_status[washer.fault_code]}}({{washer.last_fault_report | moment("MM-DD HH:mm")}})</h3>
        <div class="card-reservation">
          <md-button-toggle md-single class="md-button-group" v-if="washer.status">
            <md-button>剩余时间：{{washer.remaining_time}}分钟</md-button>
            <md-button>查看当前订单</md-button>
          </md-button-toggle>
          <md-button-toggle md-single class="md-button-group" v-if="!washer.status">
            <md-button>空闲时间：- 分钟</md-button>
            <md-button>查看历史订单</md-button>
          </md-button-toggle>
        </div>
      </md-card-content>
      <md-card-actions>
        <md-button class="md-primary">More Info</md-button>
      </md-card-actions>
    </md-card>
</template>

<script>
import moment from 'moment'
window.moment = moment

export default {
  props: {
    stats: {
      type: Object,
      required: true
    },
    washer: {
      type: Object,
      required: true
    }
  },
  computed: {
    runTime: function() {
      if (this.washer) {
        let dateFormat = 'YYYY-MM-DD HH:mm:ss'
        let date = moment(this.washer.created_at.date, dateFormat)
        return moment().diff(date, 'days')
      } else {
        return 0
      }
    }
  },
  data() {
    return {
      washerStatus: [ '空闲', '已下单', '已支付', '洗衣中' ],
      online: ['不在线', '在线'],
      washer_status: {'alarmCancel': '报警解除', 'doorLockErr': '门锁故障', 'spinUnbalanceAlarm': '不平衡不能甩干提醒', 'doorErr': '门盖异常', 'drainErr': '排水异常', 'inWaterErr': '进水异常', 'waterLevelSensorErr': '水位传感器异常', 'overflowAlarm': '水位溢出报警'}
    }
  },
  mounted() {}
}
</script>

<style lang="scss" scoped>
.washer-card{
  width: 100%;
  .md-subhead {
    .md-icon {
      $size: 16px;

      width: $size;
      min-width: $size;
      height: $size;
      min-height: $size;
      font-size: $size;
      line-height: $size;
    }

    span {
      vertical-align: middle;
    }
  }

  .card-reservation {
    margin-top: 8px;
    display: flex;
    align-items: center;
    justify-content: space-around;

    .md-icon {
      margin: 8px;
      color: rgba(#000, .54) !important;
    }

    .md-button {
      border-radius: 2px !important;
    }
  }
}
.md-body-2 {
  display: block;
}
.md-card .md-title {
  margin-bottom: 10px;
}
</style>
