<template>
  <div class='md-sidenav main-sidebar md-left md-fixed md-theme-default'>
    <div class='md-sidenav-content'>
      <div class="md-toolbar vue-material-logo md-theme-white">
        <router-link to="/home" class="logo-link">
          <img class='logo' src="../assets/images/logo.png" alt="Vue">
          <p><strong>轻氧智能洗衣</strong></p>
        </router-link>
      </div>
      <div class="phone-viewport nav-list">
        <md-list>
          <md-list-item>
          <router-link to="/universities/0" :class="{active: $route.name === 'UniversityOrderStats'}">
              <md-icon>home</md-icon>
              <span>首页</span>
            </router-link>
          </md-list-item>

          <md-list-item>
            <router-link to="/universities/0/orderList" :class="{active: $route.name === 'UniversityOrderList'}">
              <md-icon>menu</md-icon>
              <span>订单</span>
            </router-link>
          </md-list-item>
          <md-list-item v-if="$user.current.user_type === 1">
            <router-link to="/users" :class="{active: $route.name === 'Users'}">
              <md-icon>people</md-icon>
              <span>用户</span>
            </router-link>
          </md-list-item>
          <md-list-item>
            <router-link to="/cities" :class="{active: $route.name === 'Cities'}">
              <md-icon>location_city</md-icon>
              <span>城市</span>
            </router-link>
          </md-list-item>

          <md-list-item>
          <router-link to="/universities" v-bind:class="{ not_active: $route.name === 'Buildings', active: $route.name === 'UniversitiesDefault' }">
              <md-icon>school</md-icon>
              <span>学校</span>
            </router-link>
          </md-list-item>

          <!-- <md-list-item> -->
          <!--   <router-link to="/vendors"> -->
          <!--     <md-icon>local_mall</md-icon> -->
          <!--     <span>供应商</span> -->
          <!--   </router-link> -->
          <!-- </md-list-item> -->

          <md-list-item v-if="$user.current.user_type === 1">
            <router-link to="/banners" :class="{active: $route.name === 'Banners'}">
              <md-icon>assistant_photo</md-icon>
              <span>Banner</span>
            </router-link>
          </md-list-item>

          <md-list-item v-if="$user.current.user_type === 1">
            <router-link to="/workers" :class="{active: $route.name === 'Workers'}">
              <md-icon>accessibility</md-icon>
              <span>员工</span>
            </router-link>
          </md-list-item>
          <md-list-item v-if="$user.current.user_type === 1">
            <router-link to="/operators" :class="{active: $route.name === 'Operators'}">
              <md-icon>person outline</md-icon>
              <span>运营商</span>
            </router-link>
          </md-list-item>

          <!--<md-list-item v-if="$user.current.user_type === 1">-->
            <!--<router-link to="/operatorsAccount" :class="{active: $route.name === 'OperatorsAccount'}">-->
              <!--<md-icon>person outline</md-icon>-->
              <!--<span>运营商员工</span>-->
            <!--</router-link>-->
          <!--</md-list-item>-->

          <md-list-item v-if="$user.current.user_type === 1">
            <router-link to="/services" :class="{active: $route.name === 'Services'}">
              <md-icon>local_laundry_service</md-icon>
              <span>服务</span>
            </router-link>
          </md-list-item>

          <md-divider class=""></md-divider>
        </md-list>
      </div>
    </div>
  </div>
</template>

<script>
  export default {}
</script>
<style lang="scss" src="./LeftSideBar.scss"></style>
