<template>
  <div class='uni-list'>
    <div class='uni-tool-list'>
      <md-layout md-gutter>
        <md-layout md-flex="20">
          <md-menu>
            <md-button md-menu-trigger class='select-city'>{{selectedCity}}<md-icon>arrow_drop_down</md-icon></md-button>
            <md-menu-content>
              <md-menu-item v-for='city in cities' :key='city.id' @click.native="citySelected(city.name)">{{city.name}}</md-menu-item>
            </md-menu-content>
          </md-menu>
        </md-layout>
        <md-layout md-flex="60" class='tool-middle'>
          <form novalidate @submit.stop.prevent="searchByName()">
            <input class='search-by-name' placeholder="按供应商名搜索..." v-model='vendorName'>
          </form>
        </md-layout>
        <md-layout md-flex="20">
          <div class='tool-icons'>
            <md-button @click.native="openDialog('add-vendor-form')" class="add-vendor md-icon-button md-raised md-warn" id='add-vendor'>
              <md-icon>add</md-icon>
              <md-tooltip md-direction="top">添加供应商</md-tooltip>
            </md-button>
          </div>
        </md-layout>
      </md-layout>
    </div>

    <md-dialog md-open-from="#add-vendor" md-close-to="#add-vendor" ref="add-vendor-form" class='add-vendor'>
      <md-dialog-title>添加供应商</md-dialog-title>
      <md-dialog-content>
        <form novalidate @submit.stop.prevent="submit">
          <md-input-container>
            <label>供应商名称</label>
            <md-input v-model="vendor.name"></md-input>
          </md-input-container>
          <md-input-container>
            <label>城市</label>
            <md-input v-model="vendor.city"></md-input>
          </md-input-container>
        </form>
      </md-dialog-content>
      <md-dialog-actions>
        <md-button class="md-primary" @click.native="cancelDialog('add-vendor-form')">取消</md-button>
        <md-button class="md-primary" @click.native="submitDialog('add-vendor-form')" :disabled="disableSubmit">确认提交</md-button>
      </md-dialog-actions>
    </md-dialog>
    <md-table>
      <md-table-header>
        <md-table-row>
          <md-table-head class='center'>供应商名称</md-table-head>
          <md-table-head class='center'>城市</md-table-head>
          <md-table-head class='center'>洗衣机数量</md-table-head>
        </md-table-row>
      </md-table-header>
      <md-table-body>
        <md-table-row v-for="ven in vendors" :key="ven.id">
          <md-table-cell>
            <router-link :to="{name: 'Buildings', params: {uid: ven.id}}" class='ven-name'>
              {{ven.name}}
            </router-link>
          </md-table-cell>
          <md-table-cell>{{ven.city}}</md-table-cell>
          <md-table-cell>{{ven.washer_count || 0}}</md-table-cell>
        </md-table-row>
      </md-table-body>
    </md-table>
  </div>
</template>

<script>

export default {
  data() {
    return {
      cities: [],
      vendor: [],
      vendorName: null,
      vendors: [],
      disableSubmit: false,
      selectedCity: '全部城市'
    }
  },
  mounted() {
    this.getCities()
    this.getvendors()
  },
  methods: {
    getvendors(params) {
      var ven = this.$resource('vendors?city={city}&name={name}')
      ven.get(params).then(res => {
        this.vendors = res.body
      })
    },
    getCities() {
      this.$resource('cities').get().then(res => {
        this.cities = res.body
        this.cities.unshift({
          id: 0,
          name: '全部城市'
        })
      })
    },
    citySelected(city) {
      this.selectedCity = city
      this.getvendors({city: city})
    },
    searchByName() {
      this.getvendors({name: this.vendorName})
    },
    openDialog(ref) {
      this.$refs[ref].open()
    },
    cancelDialog(ref) {
      this.vendor = null
      this.$refs[ref].close()
    },
    submitDialog(ref) {
      this.disableSubmit = true
      this.$http.post('vendors', {
        name: this.vendor.name, city: this.vendor.city
      }).then((res) => {
        if (res.body.message) {
          this.$store.dispatch('error', res.body.message)
        } else {
          this.$store.dispatch('success', '供应商添加成功')
          this.$refs[ref].close()
          this.vendors.push(res.body)
        }
        this.disableSubmit = false
      }, (res) => {
        this.disableSubmit = false
        this.$store.dispatch('error', res.body.message)
      })
    }
  }
}
</script>

<style lang="scss" scoped>
.md-table .md-table-head {
  font-size: 16px;
}
.uni-list {
  background: #fff;
}
.uni-tool-list {
  padding: 3px 10px;
  border-bottom: 1px solid #ddd;
  height: 56px;
  .tool-icons {
    width: 100%;
    padding: 4px;
    text-align: right;
  }
  .tool-middle {
    form {
      margin: auto;
      margin-top: 7px;
    }
    .search-by-name {
      text-align: center;
      height: 35px;
      width: 500px;
      font-size: 14px;
    }
  }
}
.add-vendor {
  cursor: pointer;
  margin-top: 10px;
}
.select-city {
  width: 160px;
  text-align: left;
  border: 1px solid #ddd;
}
.ven-name {
  margin: auto;
  color: #000 !important;
}
</style>
