<template>
  <div class='login-form'>
    <md-layout md-gutter>
      <md-layout md-flex="30" md-flex-offset="35">
        <form novalidate @submit.stop.prevent="submit">
          <div class='title'> <p><strong>轻氧洗衣机功能测试</strong> </p></div>
          <div class='inputs'>
            <md-input-container>
              <label>输入洗衣机IMEI码</label>
              <md-input type="number" autofocus="autofocus" v-model="deviceId"></md-input>
            </md-input-container>
            <br />
            <md-button type="submit" :disabled="buttonDisabled" class="md-raised md-primary">{{buttonText}}</md-button>
          </div>
        </form>
        <div class='tips'>
          <span class="md-subheading">注意：设备通电之后需要等待2-3分钟才能联网测试。</span>
        </div>
      </md-layout>
      <md-speed-dial md-open="hover" class="md-fab-bottom-right">
        <md-button class="md-fab" md-fab-trigger>
          <md-icon md-icon-morph>close</md-icon>
          <md-icon>person_outlet</md-icon>
        </md-button>

        <md-button class="md-fab md-primary md-mini md-clean" @click.native='logout'>
          <md-icon>exit_to_app</md-icon>
          <md-tooltip md-direction="left">登出</md-tooltip>
        </md-button>

        <md-button class="md-fab md-primary md-mini md-clean">
          <md-icon>person_outlet</md-icon>
          <md-tooltip md-direction="left">个人信息</md-tooltip>
        </md-button>
      </md-speed-dial>
    </md-layout>
  </div>
</template>

<script>
import router from '../router'

export default {
  data() {
    return {
      deviceId: '',
      buttonDisabled: false,
      buttonText: '重置洗衣机'
    }
  },
  methods: {
    submit() {
      if (!/^[0-9]{15}$/.test(this.deviceId)) {
        this.$store.dispatch('error', '您所输入的IMEI码格式错误', 'top center')
        return false
      }
      this.buttonDisabled = true
      this.buttonText = '设备响应中, 请稍后...'
      this.$http.post('washers/' + this.deviceId + '/reset').then(res => {
        var body = res.body
        if (body.retCode === '00000') {
          this.$store.dispatch('success', res.body.retInfo, 'top center')
        } else {
          this.$store.dispatch('error', res.body.retInfo, 'top center')
        }
        this.buttonText = '重置洗衣机'
        this.buttonDisabled = false
      })
    },
    logout() {
      this.$user.logout()
      this.$store.dispatch('success', '您已登出', 'top center')
      router.push({ name: 'Login' })
    }
  }
}
</script>

<style lang="scss">
.tips {
  margin: auto;
  margin-top: 40px;
}
.login-form {
  .md-layout {
    .md-layout {
      form {
        background: #fff;
        margin-top: 100px;
        width: 100%;
        font-size: 20px;
        border-radius: 4px;
        box-shadow: 2px 2px 5px 1px rgba(0, 0, 0, 0.2);
        .title {
          height: 80px;
          width: 100%;
          font-size: 20px;
          background: #03a9f4;
          color: white;
          line-height: 150%;
          border-radius: 4px 4px 0 0;
          padding-top: 25px;
          box-shadow: 0 2px 5px 1px rgba(0, 0, 0, 0.2);
          p {
            margin: 0px;
          }
        }
        .md-button {
          padding: 4px 25px;
          font-size: 18px;
          font-weight: bold;
          color: #fff !important;
        }
        .inputs {
          padding: 40px 30px 60px 30px;
        }
      }
    }
  }
}
</style>
