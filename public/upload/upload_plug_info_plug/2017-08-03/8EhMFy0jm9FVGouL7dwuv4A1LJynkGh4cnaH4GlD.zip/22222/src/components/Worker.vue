<template>
  <div class='worker-list'>
    <md-tabs>
      <md-tab md-label="修改个人信息">
      </md-tab>
    </md-tabs>
    <div class='user-form'>
      <md-whiteframe md-elevation="4">
        <form novalidate @submit.stop.prevent="submit">
          <md-input-container>
          <label>姓名</label>
          <md-input v-model="worker.name"></md-input>
          </md-input-container>
          <md-input-container>
          <label>邮箱</label>
          <md-input v-model="worker.email"></md-input>
          </md-input-container>
          <md-input-container>
          <label>电话</label>
          <md-input v-model="worker.phone"></md-input>
          </md-input-container>
          <md-input-container>
          <label>昵称</label>
          <md-input v-model="worker.nickname"></md-input>
          </md-input-container>
          <md-input-container>
          <label>密码</label>
          <md-input v-model="worker.password" type='password'></md-input>
          </md-input-container>
        </form>
        <md-button class="md-raised md-primary" @click.native="submit()" :disabled="disableSubmit">确认提交</md-button>
      </md-whiteframe>
    </div>
  </div>
</template>

<script>

export default {
  data() {
    return {
      worker: {},
      disableSubmit: false
    }
  },
  mounted() {
    this.getworker()
  },
  methods: {
    async getworker() {
      let id = this.$route.params.wid
      let res = await this.$resource(`workers/${id}`).get()
      this.worker = res.body
    },
    async submit(ref) {
      this.disableSubmit = true
      try {
        await this.$http.put(`workers/${this.worker.id}`, this.worker)
        this.$store.dispatch('success', '更新成功')
        this.disableSubmit = false
      } catch (e) {
        this.$store.dispatch('error', e.body.message)
        this.disableSubmit = false
      }
    }
  }
}
</script>

<style lang="scss" scoped>
.md-whiteframe {
  background: #fff;
  margin: 40px;
  padding: 60px;
}
</style>
