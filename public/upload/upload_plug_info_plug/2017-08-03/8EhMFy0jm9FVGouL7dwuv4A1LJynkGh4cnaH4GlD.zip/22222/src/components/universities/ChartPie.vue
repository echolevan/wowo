<template>
  <md-whiteframe md-elevation="1">
    <!-- <figure><chart :options="options" auto-resize theme="macarons"></chart></figure> -->
    <figure :style="figureStyle"><chart :options="options" :style="chartStyle" class='pie' auto-resize theme="macarons"></chart></figure>
  </md-whiteframe>
</template>

<script>
  export default {
    props: {
      data: {
        type: Array,
        required: true
      },
      name: String,
      title: {
        type: String,
        required: true
      },
      chartStyle: {
        type: Object
      },
      figureStyle: {
        type: Object
      }
    },
    name: 'ChartBar',
    data() {
      return {
        options: {
          title: {
            text: this.title,
            x: 'center',
            textStyle: {
              fontSize: 14
            }
          },
          tooltip: {
            trigger: 'item',
            formatter: '{a} <br/>{b} : {c} ({d}%)'
          },
          series: [{
            name: this.name || this.title,
            type: 'pie',
            radius: '55%',
            center: ['50%', '60%'],
            data: [],
            itemStyle: {
              emphasis: {
                shadowBlur: 10,
                shadowOffsetX: 0,
                shadowColor: 'rgba(0, 0, 0, 0.5)'
              }
            }
          }]
        }
      }
    },
    watch: {
      data(val) {
        this.setData(val)
      }
    },
    methods: {
      setData(data) {
        if (!Array.isArray(data[0])) {
          data = [data]
        }
        this.options.series = data.map((item) => {
          return {
            name: this.name || this.title,
            type: 'pie',
            radius: '55%',
            center: ['50%', '60%'],
            data: item,
            itemStyle: {
              emphasis: {
                shadowBlur: 10,
                shadowOffsetX: 0,
                shadowColor: 'rgba(0, 0, 0, 0.5)'
              }
            }
          }
        })
      }
    }
  }
</script>

<style lang="scss" scoped>
.md-whiteframe {
  cursor: pointer;
  &:hover {
    border: 1px solid #03A9F4;
    font-weight: bold;
  }
}
figure {
  width: 100%;
  margin: 20px 0px 0px;
}
.echarts {
  height: 220px;
  width: 100%;
}
</style>
