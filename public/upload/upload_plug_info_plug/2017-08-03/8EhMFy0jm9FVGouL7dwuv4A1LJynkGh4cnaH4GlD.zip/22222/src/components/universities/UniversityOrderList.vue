<template>
  <div class='uni-page-content'>
    <md-table-card>
      <md-toolbar class='order-table-toolbar'>
        <md-layout md-gutter>
          <md-layout md-flex="30" class='order-table-title'>
            <strong>订单列表</strong>
            <strong class='order-count'>共 {{orderCount}} 单</strong>
            <a :href="`${api_host}/api/v1/order_excel?uid=${uid}&started_at=${started_at}&ended_at=${ended_at}&timestamp=${timestamp}&token=${md5_token}`" style="padding-left: 20px;text-decoration:none;color: #03a9f4" >导出EXCEL</a>
          </md-layout>
          <!--<md-layout md-flex="20" class='tool-middle'>-->
          <!---->
          <!--</md-layout>-->
          <md-layout md-flex="25" style="border-bottom: 1px solid #ddd">
            <md-menu class='select-uni-menu'>
              <md-button md-menu-trigger class='select-uni'>{{service_name}}<md-icon>arrow_drop_down</md-icon></md-button>
              <md-menu-content>
                <md-menu-item  @click.native="serviceSelected('全部服务')">全部服务</md-menu-item>
                <md-menu-item v-for='s in servicesName' :key='s.id' @click.native="serviceSelected(s.name)">{{s.name}}</md-menu-item>
              </md-menu-content>
            </md-menu>

            <form novalidate @submit.stop.prevent="getOrders()" style="padding-top: 10px">
              <input class='search-by-name' autofocus='autofocus' v-model="search_phone" placeholder="输入手机号搜索..." style="padding: 5px;">
            </form>

          </md-layout>
          <md-layout md-flex="45" class=''>

            <md-tabs md-right class='md-theme-default md-transparent' @change="tabChanged">
              <md-tab md-label='全部订单'></md-tab>
              <md-tab :md-label="status" v-for="(status, index) in orderStatus" :key='index'>
              </md-tab>
            </md-tabs>
          </md-layout>
        </md-layout>
      </md-toolbar>
      <md-table md-sort="dessert" md-sort-type="desc" @sort="onSort" class='order-table-list'>
        <md-table-header>
          <md-table-row>
            <md-table-head md-sort-by="id" width="50">ID</md-table-head>
            <md-table-head>订单号</md-table-head>
            <md-table-head>用户电话</md-table-head>
            <md-table-head>用户姓名</md-table-head>
            <md-table-head>服务类型</md-table-head>
            <md-table-head>价格</md-table-head>
            <md-table-head>优惠金额</md-table-head>
            <md-table-head>实际消费金额</md-table-head>
            <md-table-head>订单状态</md-table-head>
            <md-table-head md-sort-by="created_at">下单时间</md-table-head>
            <md-table-head v-if="activeTab === 5">取消原因</md-table-head>
            <md-table-head v-else md-sort-by="started_at"> 开始时间 </md-table-head>
            <md-table-head md-sort-by="remaining_time">剩余时间</md-table-head>
            <md-table-head>宿舍楼</md-table-head>
            <md-table-head>洗衣机</md-table-head>
          </md-table-row>
        </md-table-header>

        <md-table-body>
          <md-table-row v-for="(order, index) in orders" :key="index" :md-item="order">
            <md-table-cell class='center'>{{order.id}}</md-table-cell>
            <md-table-cell>{{order.number}}</md-table-cell>
            <md-table-cell>{{order.phone}}</md-table-cell>
            <md-table-cell>{{order.name || '-'}}</md-table-cell>
            <md-table-cell>{{order.service_name}}</md-table-cell>
            <md-table-cell>{{order.service_price}}</md-table-cell>
            <md-table-cell>{{order.gift_amount}}</md-table-cell>
            <md-table-cell>{{order.real_amount}}</md-table-cell>
            <md-table-cell>{{orderStatus[order.state]}}</md-table-cell>
            <md-table-cell>
              <span style='margin: auto'>{{order.created_at | moment("from", "now", true)}}前</span>
              <md-tooltip md-direction="top">{{order.created_at | moment("MM月DD HH:mm:ss")}}</md-tooltip>
            </md-table-cell>
            <md-table-cell v-if='activeTab === 5'><span>{{order.cancel_reason}}</span></md-table-cell>
            <md-table-cell v-else>
              <div v-if='order.started_at' style='margin: auto'>
                <span>{{order.started_at | moment("from", "now", true)}}前</span>
                <md-tooltip md-direction="top">{{order.started_at | moment("MM月DD HH:mm:ss")}}</md-tooltip>
              </div>
              <div v-else>
                <span>-</span>
              </div>
            </md-table-cell>
            <md-table-cell class='center'>{{order.remaining_time}} 分钟</md-table-cell>
            <md-table-cell> <small>{{order.washer_location}}</small> </md-table-cell>
            <md-table-cell> {{order.washer_name}} </md-table-cell>
          </md-table-row>
        </md-table-body>
      </md-table>

      <md-table-pagination
        :md-size="currentSize"
        :md-total="orderCount"
        :md-page="currentPage"
        md-label="每页显示行数"
        md-separator="of"
        :md-page-options="pageRows"
        class="order-list-pagination"
        @page="pageChanged"
        @size="sizeChanged"
        @pagination="onPagination"></md-table-pagination>
    </md-table-card>
  </div>
</template>

<script>
  import { mapState } from 'vuex'
  import router from '../../router'
  import md5 from 'js-md5'

  export default {
    computed: mapState(['university', 'startTime', 'endTime', 'orderStatus']),
    data() {
      return {
        servicesName: [],
        orders: [],
        activeTab: 0,
        orderCount: 0,
        totalPages: 100,
        currentPage: 1,
        currentSize: 10,
        sortOptions: {},
        pageRows: [10, 25, 50],
        api_host: '',
        uid: 0,
        started_at: 0,
        ended_at: 0,
        md5_token: '',
        timestamp: '',
        service_name: '全部服务',
        search_phone: ''
      }
    },
    watch: {
      university(val) {
        this.uid = val.id
        router.push({ name: 'UniversityOrderList', params: { uid: val.id } }, (e) => {
          this.getOrders()
          this.currentPage = 1
        })
      },
      endTime(val) {
        this.reloadWhenTimeChange()
      },
      startTime(val) {
        this.reloadWhenTimeChange()
      }
    },
    mounted() {
      let timestamp = new Date().getTime().toString()
      this.md5_token = md5(timestamp + timestamp.substr(0, 6))
      this.timestamp = timestamp
      this.api_host = process.env.API_HOST
      this.$store.commit('uniTabChanged', 1)
      this.getServices()
    },
    methods: {
      sizeChanged(size) {
        this.currentSize = size
      },
      pageChanged(page) {
        this.currentPage = page
      },
      onSort(e) {
        this.currentPage = 1
        this.sortOptions = {
          order_by_name: e.name,
          order_by_type: e.type
        }
        this.getOrders()
      },
      onPagination(e) {
        this.getOrders(e)
      },
      getStateParams() {
        let index = this.activeTab - 1
        if (index < 0) {
          return {}
        } else {
          return {state: index}
        }
      },
      getServices() {
        this.$http.get('order_type').then(res => {
          console.log(res)
          this.servicesName = res.data
        })
      },
      serviceSelected(name) {
        this.service_name = name
        console.log(this.service_name)
        this.getOrders()
      },
      tabChanged(index) {
        this.activeTab = index
        index = index - 1
        this.getOrders()
      },
      reloadWhenTimeChange() {
        this.ended_at = this.endTime.time
        this.started_at = this.startTime.time
        let query = {
          end_time: this.endTime.time,
          start_time: this.startTime.time
        }
        this.$router.changeQuery(query, (e) => {
          this.getOrders()
        })
      },
      getOrders(params = {}) {
        let defaultParams = {
          page: this.currentPage,
          size: this.currentSize
        }
        let keyParams = {}
        let id = this.$route.params.uid
        if (parseInt(id)) {
          keyParams = { key_name: 'orders.org_id', key_value: id }
        }
        let serP = {}
        serP = { service_name: this.service_name }
        let serPhone = {}
        serPhone = { s_phone: this.search_phone }
        params = Object.assign(
          defaultParams,
          params,
          this.sortOptions,
          this.$route.query,
          keyParams,
          serPhone,
          serP,
          this.getStateParams()
        )
        let url = `orders`
        this.$http.get(url, {params: params}).then(res => {
          this.orders = res.body.orders
          this.orderCount = res.body.count
        })
      }
    }
  }
</script>

<style lang="scss">


  .order-table-list.md-table  {
    .md-table-header .md-table-head .md-table-head-container {
      text-align: center;
      .md-table-head-text {
        width: 100%;
        text-align: center;
        padding: 0px;
      }
    }
    .md-table-cell .md-table-cell-container {
      text-align: center;
      display: inline-block !important;
      padding: 0px;
    }
    .md-sortable:first-of-type .md-sortable-icon {
      left: 5px;
    }
    .md-table-cell:last-child .md-table-cell-container {
      padding-right: 0px;
    }
  }
  .order-table-toolbar {
    .md-tab-header-container span {
      color: #000;
    }
  }
  .md-table-card .order-list-pagination.md-table-pagination .md-select {
    margin-left: 5px;
  }
</style>

<style lang="scss" scoped>
  .md-table-card .md-toolbar.order-table-toolbar {
    padding: 0px;
  }
  .order-table-title {
    padding-left: 10px;
    padding-top: 15px;
    border-bottom: 1px solid rgba(0, 0, 0, .12);
    .order-count {
      margin-left: 40px;
    }
  }
  .order-table-toolbar {
    padding-right: 0px;
  }
  .uni-page-content {
    padding: 20px 25px 100px;
  }
</style>
