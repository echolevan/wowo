<template>
  <md-layout md-gutter class='info-title'>
    <md-layout v-for="(item, key) in data" :key="item">
      <md-whiteframe md-elevation="1" @click.native="pannelSelected(key)">
        {{key}}
        <br>
        <strong>{{item}}</strong>
      </md-whiteframe>
    </md-layout>
  </md-layout>
</template>

<script>
  export default {
    props: {
      data: {}
    },
    mounted() {},
    methods: {
      pannelSelected(key) {
        this.$emit('selected', key)
      }
    }
  }
</script>

<style lang="scss" scoped>
.md-whiteframe {
  cursor: pointer;
  &:hover {
    border: 1px solid #03A9F4;
    font-weight: bold;
  }
}
.info-title {
  .md-layout {
    padding: 0px 5px;
  }
  .md-whiteframe {
    width: 100%;
    height: 60px;
    margin-left: auto;
    margin-right: auto;
    padding: 20px 0px;
    background: #fff;
  }
}
</style>
