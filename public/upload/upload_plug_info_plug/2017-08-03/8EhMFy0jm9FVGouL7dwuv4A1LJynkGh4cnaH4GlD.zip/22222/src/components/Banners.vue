<template>
  <div class='banner-list'>
    <md-tabs>
      <md-tab id="movies" md-label="服务类型">
      </md-tab>
    </md-tabs>
    <md-layout md-gutter style='padding: 40px 40px'>
      <md-layout class='banner-info' md-flex="50" v-for="b in banners" :key="b.id"  style='padding: 20px'>
        <md-card md-with-hover>
          <md-card-media>
            <img :src="b.image" alt="banner">
          </md-card-media>

          <md-card-header>
            <div class="md-title">{{b.name}}</div>
            <div class="md-subhead" style='font-size: 16px;'>
              上架时间： {{b.start_at.date | moment("MM月DD")}} - {{b.end_at.date | moment("MM月DD")}}
            </div>
          </md-card-header>

          <md-card-actions>
            <md-button @click.native="openDelete('delete-banner', b)">删除</md-button>
            <md-button @click.native="openDialog('add-banner-form', b)">编辑</md-button>
          </md-card-actions>
        </md-card>
      </md-layout>
    </md-layout>
    <md-dialog-confirm
      :md-title="confirm.title"
      :md-content-html="confirm.contentHtml"
      :md-ok-text="confirm.ok"
      :md-cancel-text="confirm.cancel"
      @close="onConfirmClose"
      ref="delete-banner">
    </md-dialog-confirm>
    <md-dialog md-open-from="#add-banner" md-close-to="#add-banner" ref="add-banner-form" class='add-banner'>
      <md-dialog-title>{{title}}</md-dialog-title>
      <md-dialog-content>
        <form novalidate @submit.stop.prevent="submit">
          <md-input-container>
            <label>标题</label>
            <md-input v-model="banner.name"></md-input>
          </md-input-container>
          <md-input-container>
            <datepicker :date="startTime" :option="startOption" @change="startTimeChange" class='banner-time'></datepicker>
          </md-input-container>
          <md-input-container>
            <datepicker :date="endTime" :option="endOption" @change="endTimeChange" class='banner-time'></datepicker>
          </md-input-container>
          <md-input-container>
            <label>图片网址</label>
            <md-input v-model="banner.image"></md-input>
          </md-input-container>
        </form>
      </md-dialog-content>
      <md-dialog-actions>
        <md-button class="md-primary" @click.native="cancelDialog('add-banner-form')">取消</md-button>
        <md-button class="md-primary" @click.native="submitDialog('add-banner-form')" :disabled="disableSubmit">确认提交</md-button>
      </md-dialog-actions>
    </md-dialog>
    <md-button class="md-fab md-fab-top-right" @click.native="openDialog('add-banner-form')">
      <md-icon>add</md-icon>
    </md-button>
  </div>
</template>

<script>

import moment from 'moment'
import dOption from '../datepicker_options'

var dateFormat = 'YYYY-MM-DD HH:mm:ss'
function formatDate(date) {
  return moment(date, dateFormat).format(dateFormat)
}

export default {
  data() {
    return {
      banner: {},
      banners: [],
      title: '添加Banner',
      disableSubmit: false,
      endTime: { time: '' },
      startTime: { time: '' },
      startOption: Object.assign({}, dOption, {
        placeholder: '开始时间'
      }),
      endOption: Object.assign({}, dOption, {
        placeholder: '结束时间'
      }),
      confirm: {
        title: '确认删除该Banner吗？',
        contentHtml: '请确认改Benner所在的活动已下架，再进行删除，谨慎操作。',
        ok: '确定删除',
        cancel: '取消'
      }
    }
  },
  mounted() {
    this.getBanners()
  },
  methods: {
    openDelete(ref, banner) {
      this.banner = banner
      this.$refs[ref].open()
    },
    async getBanners() {
      let res = await this.$resource('banners').get()
      this.banners = res.body
    },
    async onConfirmClose(type) {
      if (type === 'ok') {
        try {
          await this.$http.delete(`banners/${this.banner.id}`, this.banner)
          this.banners = this.banners.filter(b => b.id !== this.banner.id)
          this.$store.dispatch('success', '删除成功')
        } catch (e) {
          this.$store.dispatch('success', '删除失败')
        }
      }
    },
    openDialog(ref, banner = {}) {
      this.banner = banner
      if (banner.id) {
        this.startTime = {
          time: formatDate(banner.start_at.date)
        }
        this.endTime = {
          time: formatDate(banner.end_at.date)
        }
        this.banner.start_at = banner.start_at
        this.banner.end_at = banner.end_at
      } else {
        this.startTime = { time: '' }
        this.endTime = { time: '' }
      }
      this.$refs[ref].open()
    },
    editbanner(banner, ref) {
      this.banner = banner
      this.$refs[ref].open()
    },
    cancelDialog(ref) {
      this.banner = {}
      this.$refs[ref].close()
    },
    endTimeChange(date) {
      this.banner.end_at = { date: date }
    },
    startTimeChange(date) {
      this.banner.start_at = { date: date }
    },
    async submitDialog(ref) {
      this.disableSubmit = true
      try {
        const params = {
          name: this.banner.name,
          image: this.banner.image,
          end_at: this.banner.end_at.date,
          start_at: this.banner.start_at.date
        }
        if (this.banner.id) {
          await this.$http.put(`banners/${this.banner.id}`, params)
          this.$store.dispatch('success', '更新成功')
        } else {
          let res = await this.$http.post('banners', params)
          this.banners.push(res.body)
          this.$store.dispatch('success', '创建成功')
        }
        this.$refs[ref].close()
        this.disableSubmit = false
      } catch (e) {
        this.disableSubmit = false
        console.log(e)
        this.$store.dispatch('error', e.body.message)
      }
    }
  }
}
</script>

<style lang="scss">
.banner-time input {
  border: 0px !important;
  box-shadow: none !important;
}
</style>

<style lang="scss" scoped>
.banner-list {
  .md-table .md-table-head, .md-table .md-table-cell {
    font-size: 16px;
  }
  .md-table-row {
    cursor: pointer;
    img {
      margin: auto;
      height: 80px;
      width: 80px;
    }
    .edit-banner {
      margin: auto;
    }
  }
}
.md-fab.md-fab-top-right, .md-speed-dial.md-fab-top-right {
  top: 20px;
  right: 10px;
}
.cov-vue-date {
  width: 100%;
}
</style>
