<template>
  <div class='bui-list full-height'>
    <div v-if="parseInt($route.params.uid)">
      <router-view></router-view>
      <buildings-sidebar :university-id="$route.params.uid"> </buildings-sidebar>
    </div>
    <div v-else>
      <h1>设备管理需要先选择一所学校</h1>
    </div>
  </div>
</template>

<script>
import { mapState } from 'vuex'
import BuildingsSidebar from './BuildingsSidebar'

export default {
  components: { BuildingsSidebar },
  computed: mapState(['university']),
  data() { return {} },
  beforeRouteUpdate(to, from, next) {
    this.getWashers(to)
    next()
  },
  watch: {
    university(val) {
      let data = { name: 'UniversityBuildings', params: { uid: val.id } }
      this.$router.push(data, (e) => { this.getOrderCount() })
    }
  },
  mounted() {
    this.$store.commit('uniTabChanged', 2)
    this.getOrderCount()
    this.getWashers(this.$route)
  },
  methods: {
    getWashers(route) {
      let params = route.params
      let query = {}
      if (parseInt(params.uid)) {
        query = { org_id: params.uid }
        if (params.bid) {
          query['building_id'] = params.bid
        }
        this.$store.dispatch('getWashers', query)
      }
    },
    getOrderCount() {
      let uid = this.$route.params.uid
      if (parseInt(uid)) {
        this.$store.dispatch('getOrderCountByWasher', uid)
      }
    }
  }
}
</script>

<style lang="scss" scoped>
.bui-list {
  padding: 20px 140px 20px 25px;
}
</style>
