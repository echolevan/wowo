<template>
  <h1>Building Washers</h1>
</template>

<script>
export default {}
</script>

<style lang="scss" scoped>
</style>
