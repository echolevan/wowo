<template>
  <div>
    <div class='uni-tool-list'>
      <div class='md-tabs md-theme-default md-dynamic-height'>
        <div class='md-whiteframe md-tabs-navigation md-whiteframe-0dp md-has-label'>
          <md-layout md-gutter>
            <md-layout md-flex="20">
              <md-menu>
                <md-button md-menu-trigger class='select-city'>{{selectedCity}}<md-icon>arrow_drop_down</md-icon></md-button>
                <md-menu-content>
                  <md-menu-item v-for='city in cities' :key='city.id' @click.native="citySelected(city.name)">{{city.name}}</md-menu-item>
                </md-menu-content>
              </md-menu>
            </md-layout>
            <md-layout md-flex="60" class='tool-middle'>
              <form novalidate @submit.stop.prevent="searchByName()">
                <input class='search-by-name' autofocus='autofocus' placeholder="输入学校名搜索..." v-model='schoolName'>
              </form>
            </md-layout>
            <md-layout md-flex="20">
              <div class='tool-icons'>
                <md-button @click.native="openDialog('add-uni-form')" class="add-uni md-icon-button md-raised md-warn" id='add-uni'>
                  <md-icon>add</md-icon>
                  <md-tooltip md-direction="left">点击添加学校</md-tooltip>
                </md-button>
              </div>
            </md-layout>
          </md-layout>
        </div>
      </div>
    </div>
    <md-dialog md-open-from="#add-uni" md-close-to="#add-uni" ref="add-uni-form" class='add-uni'>
      <md-dialog-title>添加学校</md-dialog-title>
      <md-dialog-content>
        <form novalidate @submit.stop.prevent="submit">
          <md-input-container>
            <label>学校名称</label>
            <md-input v-model="school.name"></md-input>
          </md-input-container>
          <md-input-container>
            <label>城市</label>
            <md-input v-model="school.city"></md-input>
          </md-input-container>
        </form>
      </md-dialog-content>
      <md-dialog-actions>
        <md-button class="md-primary" @click.native="cancelDialog('add-uni-form')">取消</md-button>
        <md-button class="md-primary" @click.native="submitDialog('add-uni-form')" :disabled="disableSubmit">确认提交</md-button>
      </md-dialog-actions>
    </md-dialog>
    <div class='uni-list'>
      <md-table>
        <md-table-header>
          <md-table-row>
            <md-table-head class='center'>学校名称</md-table-head>
            <md-table-head class='center'>城市</md-table-head>
            <md-table-head class='center'>宿舍楼数量</md-table-head>
            <md-table-head class='center'>洗衣机数量</md-table-head>
          </md-table-row>
        </md-table-header>
        <md-table-body>
          <md-table-row v-for="uni in universities" :key="uni.id">
            <md-table-cell>
              <router-link :to="{name: 'UniversityOrderStats', params: {uid: uni.id}}" class='uni-name'>
                {{uni.name}}
              </router-link>
            </md-table-cell>
            <md-table-cell>{{uni.city}}</md-table-cell>
            <md-table-cell>{{uni.building_count || 0}}</md-table-cell>
            <md-table-cell>{{uni.washer_count || 0}}</md-table-cell>
          </md-table-row>
        </md-table-body>
      </md-table>
    </div>
  </div>
</template>

<script>

export default {
  data() {
    return {
      cities: [],
      school: [],
      schoolName: null,
      universities: [],
      disableSubmit: false,
      selectedCity: '全部城市'
    }
  },
  mounted() {
    this.getCities()
    this.getUniversities()
  },
  methods: {
    getUniversities(params) {
      var uni = this.$resource('universities?city={city}&name={name}')
      uni.get(params).then(res => {
        this.universities = res.body
      })
    },
    getCities() {
      this.$resource('cities').get().then(res => {
        this.cities = res.body
        this.cities.unshift({
          id: 0,
          name: '全部城市'
        })
      })
    },
    citySelected(city) {
      this.selectedCity = city
      this.getUniversities({city: city})
    },
    searchByName() {
      this.getUniversities({name: this.schoolName})
    },
    openDialog(ref) {
      this.$refs[ref].open()
    },
    cancelDialog(ref) {
      this.school = null
      this.$refs[ref].close()
    },
    submitDialog(ref) {
      this.disableSubmit = true
      this.$http.post('universities', {
        name: this.school.name, city: this.school.city
      }).then((res) => {
        this.$store.dispatch('success', '学校添加成功')
        this.disableSubmit = false
        this.$refs[ref].close()
        this.universities.push(res.body)
      }, (res) => {
        this.disableSubmit = false
        this.$store.dispatch('error', res.body.message)
      })
    }
  }
}
</script>

<style lang="scss">
.uni-list {
  padding: 20px;
  .md-table {
    background: #fff;
    .md-table-head-container {
      height: 40px;
      padding: 6px 0px;
    }
  }
}
.md-menu-content.md-direction-bottom-right.md-active {
  .md-list-item-container.md-button {
    font-size: 14px !important;
  }
}
</style>

<style lang="scss" scoped>
.md-button.md-fab .md-icon, .md-button.md-icon-button .md-icon {
  top: 0px;
}
.md-table .md-table-head {
  font-size: 14px;
}
.uni-list {
  padding: 20px;
  .md-table {
    background: #fff;
  }
}
.uni-tool-list {
  .tool-icons {
    width: 100%;
    padding: 4px;
    margin-right: 10px;
    text-align: right;
  }
  .tool-middle {
    form {
      margin: auto;
      margin-top: 7px;
    }
    .search-by-name {
      outline: none;
      border: 0px;
      text-align: center;
      height: 35px;
      width: 500px;
      font-size: 14px;
    }
  }
}
.add-uni {
  cursor: pointer;
  margin-top: 10px;
}
.select-city {
  color: #fff;
  text-align: left;
  font-weight: bold;
  background: #29B6F6 !important;
  margin-left: 20px;
  .md-icon {
    margin-top: -8px;
  }
}
.uni-name {
  margin: auto;
  color: #000 !important;
}
</style>
