<template>
  <div class='worker-list'>
    <md-tabs>
      <md-tab md-label="员工管理">
      </md-tab>
    </md-tabs>
    <md-table-card>
      <md-table>
        <md-table-header>
          <md-table-row>
            <md-table-head class='center'>姓名</md-table-head>
            <md-table-head class='center'>邮箱</md-table-head>
            <md-table-head class='center'>电话</md-table-head>
            <md-table-head class='center'>昵称</md-table-head>
            <md-table-head class='center'>用户类型</md-table-head>
            <md-table-head class='center'>管理</md-table-head>
          </md-table-row>
        </md-table-header>
        <md-table-body>
          <md-table-row v-for="w in workers" :key="w.id">
            <md-table-cell>{{w.name}}</md-table-cell>
            <md-table-cell>{{w.email}}</md-table-cell>
            <md-table-cell>{{w.phone}}</md-table-cell>
            <md-table-cell>{{w.nickname}}</md-table-cell>
            <md-table-cell>{{userTypes[w.user_type]}}</md-table-cell>
            <md-table-cell>
              <md-button class="md-dense" @click.native="openEdit('add-worker-form', w)">编辑</md-button>
            </md-table-cell>
          </md-table-row>
        </md-table-body>
      </md-table>
    </md-table-card>
    <md-dialog md-open-from="#add-worker" md-close-to="#add-worker" ref="add-worker-form" class='add-worker'>
      <md-dialog-title>{{title}}</md-dialog-title>
      <md-dialog-content>
        <form novalidate @submit.stop.prevent="submit">
          <md-input-container>
            <label>姓名</label>
            <md-input v-model="worker.name"></md-input>
          </md-input-container>
          <md-input-container>
            <label>邮箱</label>
            <md-input v-model="worker.email"></md-input>
          </md-input-container>
          <md-input-container>
            <label>电话</label>
            <md-input v-model="worker.phone"></md-input>
          </md-input-container>
          <md-input-container>
            <label>昵称</label>
            <md-input v-model="worker.nickname"></md-input>
          </md-input-container>
          <md-input-container>
            <label>密码</label>
            <md-input v-model="worker.password" type='password'></md-input>
          </md-input-container>
          <md-radio v-model="worker.user_type" id="user_type1" name="user_type" md-value="2" class="md-primary">普通员工</md-radio>
          <md-radio v-model="worker.user_type" id="user_type2" name="user_type" md-value="1" class="md-primary">管理员</md-radio>
          <md-radio v-model="worker.user_type" id="user_type3" name="user_type" md-value="10" class="md-primary">海尔测试</md-radio>
        </form>
      </md-dialog-content>
      <md-dialog-actions>
        <md-button class="md-primary" @click.native="cancelDialog('add-worker-form')">取消</md-button>
        <md-button class="md-primary" @click.native="submitDialog('add-worker-form')" :disabled="disableSubmit">确认提交</md-button>
      </md-dialog-actions>
    </md-dialog>
    <md-button class="md-fab md-fab-top-right" @click.native="openDialog('add-worker-form')">
      <md-icon>add</md-icon>
    </md-button>
  </div>
</template>

<script>

import tools from '../tools'

export default {
  data() {
    return {
      worker: { user_type: 2 },
      workers: [],
      radio2: '',
      title: '添加员工',
      disableSubmit: false,
      userTypes: {
        '1': '管理员',
        '2': '普通员工',
        '10': '海尔测试'
      },
      confirm: {
        title: `确认删除该员工吗？`,
        ok: '确定删除',
        cancel: '取消'
      }
    }
  },
  mounted() {
    this.getworkers()
  },
  methods: {
    async onConfirmClose(type) {
      if (type === 'ok') {
        try {
          await this.$http.delete(`workers/${this.worker.id}`, this.worker)
          this.workers = this.workers.filter(serv => serv.id !== this.worker.id)
          this.$store.dispatch('success', '删除成功')
        } catch (e) {
          this.$store.dispatch('success', '删除失败')
        }
      }
    },
    iconChange(e) {
      tools.toBase64(e.target.files[0], (res) => {
        this.worker.icon = res
      })
    },
    async getworkers() {
      let res = await this.$resource('workers').get()
      this.workers = res.body
    },
    openEdit(ref, worker) {
      this.worker = worker
      this.disableSubmit = false
      this.$refs[ref].open()
    },
    openDelete(ref, serv) {
      this.worker = serv
      this.$refs[ref].open()
    },
    openDialog(ref) {
      this.worker = { user_type: 2 }
      this.disableSubmit = false
      this.$refs[ref].open()
    },
    editworker(worker, ref) {
      this.worker = worker
      this.$refs[ref].open()
    },
    cancelDialog(ref) {
      this.$refs[ref].close()
    },
    async submitDialog(ref) {
      this.disableSubmit = true
      try {
        if (this.worker.id) {
          await this.$http.put(`workers/${this.worker.id}`, this.worker)
          this.$store.dispatch('success', '更新成功')
        } else {
          let res = await this.$http.post('workers', this.worker)
          this.workers.unshift(res.body)
          this.$store.dispatch('success', '创建成功')
        }
        this.$refs[ref].close()
        this.disableSubmit = false
      } catch (e) {
        this.$store.dispatch('error', e.body.message)
        this.disableSubmit = false
      }
    }
  }
}
</script>

<style lang="scss" scoped>
.md-table .md-table-cell .md-button {
  width: 60px;
  margin: auto !important;
}
.worker-list {
  .md-table .md-table-head, .md-table .md-table-cell {
    font-size: 16px;
  }
  .md-table-row {
    cursor: pointer;
    img {
      margin: auto;
      height: 80px;
      width: 80px;
    }
    .edit-worker {
      margin: auto;
    }
  }
}
.md-fab.md-fab-top-right, .md-speed-dial.md-fab-top-right {
  top: 20px;
  right: 10px;
}
.md-table-card {
  margin: 30px;
}
</style>
