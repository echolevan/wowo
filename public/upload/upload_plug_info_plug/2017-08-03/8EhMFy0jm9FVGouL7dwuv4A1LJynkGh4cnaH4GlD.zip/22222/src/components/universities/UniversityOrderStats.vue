<template>
  <div class='full-height order-stats-content'>
    <summary-pannel :data="summary"></summary-pannel>
    <md-layout md-gutter class='figures'>
      <md-layout md-flex="75">
        <chart-bar :data="byDate.data" :x-axis-data="byDate.xAxisData" title="日订单量"> </chart-bar>
      </md-layout>
      <md-layout md-flex="25">
        <chart-pie :data="byService" title="不同服务类型订单量"></chart-pie>
      </md-layout>
    </md-layout>
    <md-layout md-gutter class='figures'>
      <md-layout md-flex="75">
        <chart-bar style='margin-top: 25px;' :data="byWasher.data" :x-axis-data="byWasher.xAxisData" title="每台机器订单量"> </chart-bar>
      </md-layout>
      <md-layout md-flex="25">
        <chart-pie :data="byWeekday" title="一周中每天订单分布" style='margin-top: 25px;'></chart-pie>
      </md-layout>
    </md-layout>
    <md-layout md-gutter class='figures'>
      <md-layout md-flex="75">
        <chart-bar-mix style='margin-top: 25px' :data="byPay.data" :x-axis-data="byPay.xAxisData" :title="'充值统计'"> </chart-bar-mix>
      </md-layout>
      <md-layout md-flex="25">
        <chart-pie :data="byPayType" title="不同金额充值频次分布" style='margin-top: 25px;'></chart-pie>
      </md-layout>
    </md-layout>
    <md-layout md-gutter class='figures'>
      <md-layout md-flex="75">
        <chart-bar style='margin-top: 25px;' :data="byUser.data" :x-axis-data="byUser.xAxisData" title="用户增长量"> </chart-bar>
      </md-layout>
      <md-layout md-flex="25">
        <chart-pie :data="byUserProvince" title="各省用户分布" style='margin-top: 25px;'></chart-pie>
      </md-layout>
    </md-layout>
    <md-layout md-gutter class='figures stats-by-hour'>
      <md-layout md-flex="33">
        <chart-pie :data="byHour" title="一天中单分布"></chart-pie>
      </md-layout>
      <md-layout md-flex="33">
        <chart-pie :data="byHourWorkday" title="工作日定单分布"></chart-pie>
      </md-layout>
      <md-layout md-flex="33">
        <chart-pie :data="byHourWeekend" title="周末定单分布"></chart-pie>
      </md-layout>
    </md-layout>
  </div>
</template>

<script>

  import { mapGetters, mapState } from 'vuex'

  import ChartBar from './ChartBar'
  import ChartBarMix from './ChartBarMix'
  import ChartPie from './ChartPie'
  import SummaryPannel from './SummaryPannel'

  export default {
    components: {ChartBar, ChartPie, SummaryPannel, ChartBarMix},
    computed: {
      ...mapGetters({
        byHour: 'orderByHour',
        byDate: 'orderByDate',
        summary: 'orderSummary',
        byWasher: 'orderByWasher',
        byWeekday: 'orderByWeekday',
        byService: 'orderByService',
        byHourWeekend: 'orderByHourWeekend',
        byHourWorkday: 'orderByHourWorkday',
        byPay: 'orderByPay',
        byPayType: 'orderByPayType',
        byUser: 'orderByUser',
        byUserProvince: 'orderByUserProvince'
      }),
      ...mapState(['university', 'startTime', 'endTime'])
    },
    watch: {
      university(val) {
        this.$router.push({ name: 'UniversityOrderStats', params: { uid: val.id } }, (e) => {
          this.getOrderStats()
        })
      },
      endTime(val) {
        this.reloadWhenTimeChange()
      },
      startTime(val) {
        this.reloadWhenTimeChange()
      }
    },
    mounted() {
      this.getOrderStats()
      this.$store.commit('uniTabChanged', 0)
    },
    methods: {
      reloadWhenTimeChange() {
        let query = {
          end_time: this.endTime.time,
          start_time: this.startTime.time
        }
        this.$router.changeQuery(query, (e) => {
          this.getOrderStats()
        })
      },
      getOrderStats(params = {}) {
        let id = this.$route.params.uid
        let query = this.$route.query
        let keyParams = {}
        if (parseInt(id)) {
          keyParams = { key_name: 'orders.org_id', key_value: id }
        }
        params = Object.assign(query, keyParams, params)
        this.$store.dispatch('getOrderStats', params)
      }
    }
  }
</script>

<style lang="scss" scoped>
  .echarts {
    height: 220px;
    width: 100%;
  }
  figure {
    width: 100%;
    margin: 0px;
  }
  .info-title {
    margin-bottom: 25px;
  }
  .figures.stats-by-hour {
    margin-top: 25px;
    .md-whiteframe {
      padding-top: 0px;
      padding-bottom: 10px
    }
  }
  .figures {
    .md-layout {
      padding: 0px 5px;
    }
    .md-whiteframe {
      width: 100%;
      margin-left: auto;
      margin-right: auto;
      padding: 20px 0px 0px;
      background: #fff;
    }
  }
  .order-stats-content {
    padding: 20px 20px 100px;
  }
</style>
