<template>
  <div class='md-sidenav main-sidebar md-right md-fixed md-theme-default bui-right-sidebar full-height'>
    <div class="phone-viewport nav-list building-names">
      <md-list>
        <md-list-item>
          <md-button md-theme="indigo" class="md-primary" @click.native="openDialog('add-bui-form')" style='padding-left: 0px'>
            <md-icon>add</md-icon>添加宿舍楼
          </md-button>
        </md-list-item>
        <md-divider class=""></md-divider>
        <md-list-item>
        <router-link :to="{'path': '/universities/' + university.id + '/buildings'}" :class="{inActive: !!$route.params.bid}">
          <span>全部宿舍楼（{{buildings.length}}）</span>
          </router-link>
        </md-list-item>
        <md-divider class=""></md-divider>
        <md-list-item v-for="bui in buildings" :key="bui.id">
          <router-link :to="{'path': '/universities/' + university.id + '/buildings/' + bui.id}">
            <span>{{bui.name}}</span>
          </router-link>
          <md-divider class=""></md-divider>
        </md-list-item>
      </md-list>
    </div>
    <md-dialog md-open-from="#add-bui" md-close-to="#add-bui" ref="add-bui-form" class='add-bui'>
      <md-dialog-title>添加宿舍楼</md-dialog-title>
      <md-dialog-content>
        <form novalidate @submit.stop.prevent="submit">
          <md-input-container>
            <md-input v-model="university.name" disabled></md-input>
          </md-input-container>
          <md-input-container>
            <label>宿舍楼名称</label>
            <md-input v-model="building.name" autofocus></md-input>
          </md-input-container>
          <md-input-container>
            <label for="运营商">运营商</label>
            <md-select name="operator_id" id="operator_id" v-model="building.operator_id">
              <md-list-item v-for="operator in operators" :key="operator.id">
                  <md-option :value="operator.id">{{operator.name}}</md-option>
              </md-list-item>
            </md-select>
          </md-input-container>
          <md-input-container>
            <label>纬度</label>
            <md-input v-model="building.latitude" autofocus></md-input>
          </md-input-container>
          <md-input-container>
            <label>经度</label>
            <md-input v-model="building.longitude" autofocus @keyup.enter.native="submitDialog('add-bui-form')"></md-input>
          </md-input-container>
        </form>
      </md-dialog-content>
      <md-dialog-actions>
        <md-button class="md-primary" @click.native="cancelDialog('add-bui-form')">取消</md-button>
        <md-button class="md-primary" @click.native="submitDialog('add-bui-form')" :disabled="disableSubmit">确认提交</md-button>
      </md-dialog-actions>
    </md-dialog>
  </div>
</template>

<script>
import { mapState } from 'vuex'

export default {
  computed: mapState(['university']),
  props: {
    universityId: {
      required: true,
      type: [String, Number]
    }
  },
  data() {
    return {
      building: {},
      buildings: [],
      operators: [],
      disableSubmit: false
    }
  },
  watch: {
    universityId(val) {
      this.getBuildings(val)
    }
  },
  mounted() {
    this.getOperators()
    if (parseInt(this.universityId)) {
      this.getBuildings(this.universityId)
    }
  },
  methods: {
    getBuildings(id) {
      var resource = this.$resource('universities{/id}/buildings')
      resource.get({id: id}).then(res => {
        this.buildings = res.body
      })
    },
    getOperators() {
      this.$resource('operators').get().then(res => {
        this.operators = res.body
      })
    },
    openDialog(ref) {
      this.$refs[ref].open()
      this.building.org_id = this.university.id
    },
    cancelDialog(ref) {
      this.$refs[ref].close()
    },
    submitDialog(ref) {
      this.disableSubmit = true
      this.$http.post('buildings', {
        name: this.building.name, org_id: this.building.org_id, operator_id: this.building.operator_id, latitude: this.building.latitude, longitude: this.building.longitude
      }).then((res) => {
        this.$store.dispatch('success', '宿舍楼添加成功')
        this.disableSubmit = false
        this.$refs[ref].close()
        this.buildings.push(res.body)
        this.building.name = null
      }, (res) => {
        this.disableSubmit = false
        this.$store.dispatch('error', res.body.message)
      })
    }
  }
}
</script>

<style lang="scss" scoped>
.building-names {
  max-height: 100%;
  min-height: 100%;
  overflow: scroll;
  padding-bottom: 160px;

  .md-list {
    padding: 0px;
    .md-list-item {
      .md-list-item-container {
        width: 100%;
        padding: 0px;
        padding-left: 2px;
        .md-icon {
          font-size: 20px;
          top: -1px;
        }
        .md-button, .md-icon {
          color: #03a9f4;
        }
        .md-button, span {
          margin: auto;
        }
        span {
          color: #333;
        }
      }
    }
  }
}

.add-bui.md-dialog-container {
  z-index: 1000;
}
.md-table .md-table-head {
  font-size: 16px;
}
.bui-name {
  margin: auto;
  color: #000 !important;
}
.select-city, .select-uni {
  width: 160px;
  text-align: left;
  border: 1px solid #ddd;
}
.bui-list {
  padding-right: 140px;
  .nav-list {
    background: #fff;
  }
}
.bui-right-sidebar {
  position: fixed;
  top: 50px;
  right: 0px;
  width: 140px;
  height: 100%;
  .md-theme-default.md-list .md-list-item .router-link-active.inActive.md-list-item-container span{
    color: #333;
  }
  .md-theme-default.md-list .md-list-item .router-link-active.md-list-item-container span{
    color: #E91E63;
  }
}
</style>
