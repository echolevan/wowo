<template>
  <div class='full-height order-stats-content'>
    <summary-pannel :data="summary" @selected="pannelSelected($event)"></summary-pannel>
    <md-layout md-gutter class='figures'>
      <md-layout md-flex="75">
        <chart-bar :data="byDate.data" :x-axis-data="byDate.xAxisData" :title="'日订单量'"> </chart-bar>
      </md-layout>
      <md-layout md-flex="25">
        <chart-pie :data="byService" title="不同服务类型订单量"></chart-pie>
      </md-layout>
    </md-layout>
    <md-layout md-gutter class='figures'>
      <md-layout md-flex="75">
        <chart-bar style='margin-top: 25px;' :data="byWasher.data" :x-axis-data="byWasher.xAxisData" :title="'每台机器订单量'"> </chart-bar>
      </md-layout>
      <md-layout md-flex="25">
        <chart-pie :data="byWeekday" title="一周中每天订单分布" style='margin-top: 25px;'></chart-pie>
      </md-layout>
    </md-layout>
    <md-layout md-gutter class='figures'>
      <md-layout md-flex="75">
        <chart-bar-mix style='margin-top: 25px' :data="byPay.data" :x-axis-data="byPay.xAxisData" :title="'充值统计'"> </chart-bar-mix>
      </md-layout>
      <md-layout md-flex="25">
        <chart-pie :data="byPayType" title="不同金额充值量" style='margin-top: 25px;'></chart-pie>
      </md-layout>
    </md-layout>
    <md-layout md-gutter class='figures stats-by-hour'>
      <md-layout md-flex="33">
        <chart-pie :data="byHour" title="一天中单分布"></chart-pie>
      </md-layout>
      <md-layout md-flex="33">
        <chart-pie :data="byHourWorkday" title="工作日定单分布"></chart-pie>
      </md-layout>
      <md-layout md-flex="33">
        <chart-pie :data="byHourWeekend" title="周末定单分布"></chart-pie>
      </md-layout>
    </md-layout>
  </div>
</template>

<script>
  import { mapGetters, mapState } from 'vuex'

  import router from '../router'

  import ChartBar from './universities/ChartBar'
  import ChartBarMix from './universities/ChartBarMix'
  import ChartPie from './universities/ChartPie'
  import SummaryPannel from './universities/SummaryPannel'

  export default {
    components: { ChartBar, ChartPie, SummaryPannel, ChartBarMix },
    computed: {
      ...mapGetters({
        byHour: 'orderByHour',
        byDate: 'orderByDate',
        summary: 'orderSummary',
        byWasher: 'orderByWasher',
        byWeekday: 'orderByWeekday',
        byService: 'orderByService',
        byHourWeekend: 'orderByHourWeekend',
        byHourWorkday: 'orderByHourWorkday',
        byPay: 'orderByPay',
        byPayType: 'orderByPayType'
      }),
      ...mapState(['university', 'startTime', 'endTime'])
    },
    data() {
      return {
        pannelPath: {
          '订单总数': 'Orders'
        }
      }
    },
    mounted() {
      this.getOrderStats()
    },
    methods: {
      pannelSelected(e) {
        let path = this.pannelPath[e]
        if (path) {
          router.push({name: path})
        }
      },
      getOrderStats(params = {}) {
        this.$store.dispatch('getOrderStats', params)
      }
    }
  }
</script>

<style lang="scss" scoped>
  .echarts {
    height: 220px;
    width: 100%;
  }
  figure {
    width: 100%;
    margin: 0px;
  }
  .info-title {
    margin-bottom: 25px;
  }
  .figures.stats-by-hour {
    margin-top: 25px;
    .md-whiteframe {
      padding-top: 0px;
      padding-bottom: 10px
    }
  }
  .figures {
    .md-layout {
      padding: 0px 5px;
    }
    .md-whiteframe {
      width: 100%;
      margin-left: auto;
      margin-right: auto;
      padding: 20px 0px 0px;
      background: #fff;
    }
  }
  .order-stats-content {
    padding: 20px 20px 100px;
  }
</style>
