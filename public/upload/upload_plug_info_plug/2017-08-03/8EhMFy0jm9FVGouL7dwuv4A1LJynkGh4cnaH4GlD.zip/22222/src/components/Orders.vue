<template>
  <div class='order-list'>
    <md-tabs md-right @change="tabChanged">
      <md-tab md-label='全部订单'></md-tab>
      <md-tab :md-label="status" v-for="(status, index) in orderStatus" :key='index'>
      </md-tab>
    </md-tabs>
    <md-table-card>
      <md-table md-sort="dessert" md-sort-type="desc" @sort="onSort" class='order-table-list'>
        <md-table-header>
          <md-table-row>
            <md-table-head md-sort-by="id" width="50">ID</md-table-head>
            <md-table-head>订单号</md-table-head>
            <md-table-head>用户ID</md-table-head>
            <md-table-head>用户姓名</md-table-head>
            <md-table-head>服务类型</md-table-head>
            <md-table-head>价格</md-table-head>
            <md-table-head>订单状态</md-table-head>
            <md-table-head md-sort-by="created_at">下单时间</md-table-head>
            <md-table-head v-if="activeTab === 5">取消原因</md-table-head>
            <md-table-head v-else md-sort-by="started_at"> 开始时间 </md-table-head>
            <md-table-head md-sort-by="remaining_time">剩余时间</md-table-head>
            <md-table-head>宿舍楼</md-table-head>
            <md-table-head>洗衣机</md-table-head>
          </md-table-row>
        </md-table-header>

        <md-table-body>
          <md-table-row v-for="(order, index) in orders" :key="index" :md-item="order">
            <md-table-cell class='center'>{{order.id}}</md-table-cell>
            <md-table-cell>{{order.number}}</md-table-cell>
            <md-table-cell>{{order.user_id}}</md-table-cell>
            <md-table-cell>{{order.name || '-'}}</md-table-cell>
            <md-table-cell>{{order.service_name}}</md-table-cell>
            <md-table-cell>{{order.service_price}}</md-table-cell>
            <md-table-cell>{{orderStatus[order.state]}}</md-table-cell>
            <md-table-cell>
              <span style='margin: auto'>{{order.created_at | moment("from", "now", true)}}前</span>
              <md-tooltip md-direction="top">{{order.created_at | moment("MM月DD HH:mm:ss")}}</md-tooltip>
            </md-table-cell>
            <md-table-cell v-if='activeTab === 5'><span>{{order.cancel_reason}}</span></md-table-cell>
            <md-table-cell v-else>
              <div v-if='order.started_at' style='margin: auto'>
                <span>{{order.started_at | moment("from", "now", true)}}前</span>
                <md-tooltip md-direction="top">{{order.started_at | moment("MM月DD HH:mm:ss")}}</md-tooltip>
              </div>
              <div v-else>
                <span>-</span>
              </div>
            </md-table-cell>
            <md-table-cell class='center'>{{order.remaining_time}} 分钟</md-table-cell>
            <md-table-cell> <small>{{order.washer_location}}</small> </md-table-cell>
            <md-table-cell> {{order.washer_name}} </md-table-cell>
          </md-table-row>
        </md-table-body>
      </md-table>

      <md-table-pagination
        :md-size="currentSize"
        :md-total="orderCount"
        :md-page="currentPage"
        md-label="每页显示行数"
        md-separator="of"
        :md-page-options="pageRows"
        class="order-list-pagination"
        @page="pageChanged"
        @size="sizeChanged"
        @pagination="onPagination"></md-table-pagination>
      </md-table-card>
  </div>
</template>

<script>
import { mapState } from 'vuex'

export default {
  data() {
    return {
      activeTab: 0,
      currentPage: 1,
      currentSize: 10,
      totalPages: 100,
      sortOptions: {},
      pageRows: [10, 25, 50]
    }
  },
  computed: mapState(['orders', 'orderCount', 'orderStatus']),
  mounted() {
    this.getOrders()
  },
  methods: {
    getOrders(params = {}) {
      this.$store.dispatch('getOrders', params)
    },
    onSort(e) {
      this.currentPage = 1
      this.sortOptions = {
        order_by_name: e.name,
        order_by_type: e.type
      }
      this.getOrders()
    },
    sizeChanged(size) {
      this.currentSize = size
    },
    onPagination(e) {
      this.getOrders(e)
    },
    pageChanged(page) {
      this.currentPage = page
    },
    tabChanged(index) {
      this.activeTab = index
      this.getOrders({ state: index - 1 })
    }
  }
}
</script>
<style lang="scss" scoped>
.md-table-card {
  margin: 30px;
}
.order-table-list.md-table  {
  background: #fff;
  .md-table-header .md-table-head .md-table-head-container {
    text-align: center;
    .md-table-head-text {
      width: 100%;
      text-align: center;
      padding: 0px;
    }
  }
  .md-table-cell .md-table-cell-container {
    text-align: center;
    display: inline-block !important;
    padding: 0px;
  }
  .md-sortable:first-of-type .md-sortable-icon {
    left: 5px;
  }
  .md-table-cell:last-child .md-table-cell-container {
    padding-right: 0px;
  }
}
</style>
