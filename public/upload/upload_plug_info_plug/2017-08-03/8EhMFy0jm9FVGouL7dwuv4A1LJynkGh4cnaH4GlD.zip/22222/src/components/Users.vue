<template>
  <div>
    <div class='uni-tool-list'>
      <div class='md-tabs md-theme-default md-dynamic-height'>
        <div class='md-whiteframe md-tabs-navigation md-whiteframe-0dp md-has-label'>
          <md-layout md-gutter>
            <md-layout md-flex="20">
              <md-menu>
                <md-button md-menu-trigger class='select-city'>{{selectedCity}}<md-icon>arrow_drop_down</md-icon></md-button>
                <md-menu-content>
                  <md-menu-item v-for='city in cities' :key='city.id' @click.native="citySelected(city.id, city.name)">{{city.name}}</md-menu-item>
                </md-menu-content>
              </md-menu>
            </md-layout>
            <md-layout md-flex="60" class='tool-middle'>
              <form novalidate @submit.stop.prevent="searchByKeywords()">
                <input class='search-by-name' autofocus='autofocus' placeholder="输入昵称或手机号搜索..." v-model='keywords'>
              </form>
            </md-layout>
          </md-layout>
        </div>
      </div>
    </div>
    <div class='uni-list'>
      <md-layout md-gutter>
        <md-layout md-flex="30" class='user-table-title'>
          <strong>用户列表 </strong>
          <strong class='user-count'>共 {{userCount}} 人</strong>
        </md-layout>
      </md-layout>
      <md-table-card>
      <md-table md-sort="dessert" md-sort-type="desc" @sort="onSort" >
        <md-table-header>
          <md-table-row>
            <md-table-head md-sort-by="id" width="50" class='center'>ID</md-table-head>
            <md-table-head class='center'>昵称</md-table-head>
            <md-table-head class='center'>OpenId</md-table-head>
            <md-table-head class='center'>手机号</md-table-head>
            <md-table-head md-sort-by="balance" class='center'>总余额／充值余额／赠送余额</md-table-head>
            <md-table-head class='center'>城市</md-table-head>
            <md-table-head class='center'>楼栋/楼层</md-table-head>
            <md-table-head md-sort-by="created_at" width="180" class='center'>注册时间</md-table-head>
            <md-table-head class='center'>操作</md-table-head>
          </md-table-row>
        </md-table-header>
        <md-table-body>
          <md-table-row v-for="uni in users" :key="uni.id">
            <md-table-cell>{{uni.id}}</md-table-cell>
            <md-table-cell>{{uni.nickname}}</md-table-cell>
            <md-table-cell>{{uni.openid}}</md-table-cell>
            <md-table-cell>{{uni.phone}}</md-table-cell>
            <md-table-cell>{{uni.balance}}／{{uni.real_balance}}／{{uni.gift_balance}}</md-table-cell>
            <md-table-cell>{{uni.city}}</md-table-cell>
            <md-table-cell>{{uni.building_name}}</md-table-cell>
            <md-table-cell>{{uni.created_at}}</md-table-cell>
            <md-table-cell>{{uni.created_at}}</md-table-cell>
          </md-table-row>
        </md-table-body>
      </md-table>
      <md-table-pagination
        :md-size="currentSize"
        :md-total="userCount"
        :md-page="currentPage"
        md-label="每页显示行数"
        md-separator="of"
        :md-page-options="pageRows"
        class="order-list-pagination"
        @page="pageChanged"
        @size="sizeChanged"
        @pagination="onPagination"></md-table-pagination>
      </md-table-card>
    </div>
  </div>
</template>

<script>

export default {
  data() {
    return {
      cities: [],
      keywords: null,
      users: [],
      userCount: 0,
      totalPages: 100,
      currentPage: 1,
      currentSize: 10,
      pageRows: [10, 25, 50],
      disableSubmit: false,
      selectedCity: '全部城市'
    }
  },
  mounted() {
    this.getCities()
    this.getUsers()
  },
  methods: {
    getUsers(params = {}) {
      let defaultParams = {
        page: this.currentPage,
        size: this.currentSize
      }
      params = Object.assign(
        defaultParams,
        params,
        this.sortOptions,
        this.$route.query
      )
      let url = `users`
      this.$http.get(url, {params: params}).then(res => {
        console.log(res)
        this.users = res.body.users
        this.userCount = res.body.count
      })
    },
    getCities() {
      this.$resource('cities').get().then(res => {
        this.cities = res.body
        this.cities.unshift({
          id: 0,
          name: '全部城市'
        })
      })
    },
    sizeChanged(size) {
      this.currentSize = size
    },
    pageChanged(page) {
      this.currentPage = page
    },
    onSort(e) {
      this.currentPage = 1
      this.sortOptions = {
        order_by_name: e.name,
        order_by_type: e.type
      }
      this.getUsers()
    },
    onPagination(e) {
      this.getUsers(e)
    },
    citySelected(id, name) {
      this.selectedCity = name
      this.getUsers({city_id: id})
    },
    searchByKeywords() {
      this.getUsers({keywords: this.keywords})
    }
  }
}
</script>

<style lang="scss">
.uni-list {
  padding: 20px;
  .md-table {
    background: #fff;
    .md-table-head-container {
      height: 40px;
      padding: 6px 0px;
    }
  }
}
.md-menu-content.md-direction-bottom-right.md-active {
  .md-list-item-container.md-button {
    font-size: 14px !important;
  }
}
</style>

<style lang="scss" scoped>
.md-button.md-fab .md-icon, .md-button.md-icon-button .md-icon {
  top: 0px;
}
.md-table .md-table-head {
  font-size: 14px;
}
.uni-list {
  padding: 20px;
  .md-table {
    background: #fff;
  }
}
.uni-tool-list {
  .tool-icons {
    width: 100%;
    padding: 4px;
    margin-right: 10px;
    text-align: right;
  }
  .tool-middle {
    form {
      margin: auto;
      margin-top: 7px;
    }
    .search-by-name {
      outline: none;
      border: 0px;
      text-align: center;
      height: 35px;
      width: 500px;
      font-size: 14px;
    }
  }
}
.add-uni {
  cursor: pointer;
  margin-top: 10px;
}
.select-city {
  color: #fff;
  text-align: left;
  font-weight: bold;
  background: #29B6F6 !important;
  margin-left: 20px;
  .md-icon {
    margin-top: -8px;
  }
}
.uni-name {
  margin: auto;
  color: #000 !important;
}
.user-table-title {
  margin-bottom: 10px;
  .user-count {
    margin-left: 20px;
  }
}
</style>
