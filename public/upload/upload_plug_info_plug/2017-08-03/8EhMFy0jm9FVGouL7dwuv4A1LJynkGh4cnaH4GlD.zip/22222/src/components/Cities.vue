<template>
  <div class='city-list'>
    <md-tabs>
      <md-tab id="movies" md-label="城市管理">
      </md-tab>
    </md-tabs>
    <div class='chip-list'>
      <md-chip md-deletable v-for='city in cities' :key='city.id' @delete="deleteCity(city)">{{city.name}}</md-chip>
    </div>
    <div class='add-city'>
      <md-button class="md-icon-button md-raised" @click.native="openDialog('add-city-form')">
        <md-icon>add</md-icon>
      </md-button>
    </div>
    <md-dialog md-open-from="#add-city" md-close-to="#add-city" ref="add-city-form" class='add-city'>
      <md-dialog-title>添加城市</md-dialog-title>
      <md-dialog-content>
        <form novalidate @submit.stop.prevent="submit">
          <md-input-container>
            <label>城市</label>
            <md-input v-model="city.name"></md-input>
          </md-input-container>
        </form>
      </md-dialog-content>
      <md-dialog-actions>
        <md-button class="md-primary" @click.native="cancelDialog('add-city-form')">取消</md-button>
        <md-button class="md-primary" @click.native="submitDialog('add-city-form')" :disabled="disableSubmit">确认提交</md-button>
      </md-dialog-actions>
    </md-dialog>
  </div>
</template>

<script>

export default {
  data() {
    return {
      city: {},
      cities: [],
      disableSubmit: false
    }
  },
  mounted() {
    this.getCities()
  },
  methods: {
    getCities() {
      this.$resource('cities').get().then(res => {
        this.cities = res.body
      })
    },
    deleteCity(city) {
      var resource = this.$resource('cities{/id}')
      resource.delete({id: city.id}).then(res => {
        this.cities = this.cities.filter(c => {
          return city.id !== c.id
        })
        this.$store.dispatch('success', '删除成功')
      }, res => {
        this.$store.dispatch('error', '删除失败' + res.body.message)
      })
    },
    openDialog(ref) {
      this.$refs[ref].open()
    },
    cancelDialog(ref) {
      this.city = {}
      this.$refs[ref].close()
    },
    submitDialog(ref) {
      this.disableSubmit = true
      this.$http.post('cities', {
        name: this.city.name
      }).then((res) => {
        if (res.body.message) {
          this.$store.dispatch('error', res.body.message)
        } else {
          this.$store.dispatch('success', '城市添加成功')
          this.$refs[ref].close()
          this.cities.push(res.body)
          this.city = {}
        }
        this.disableSubmit = false
      }, (res) => {
        this.disableSubmit = false
        this.$store.dispatch('error', res.body.message)
      })
    }
  }
}
</script>

<style lang="scss" scoped>
.md-chip {
  margin-right: 10px;
  margin-left: 10px;
}
.add-city {
  padding: 40px;
}
.chip-list {
  padding: 40px;
}
</style>
