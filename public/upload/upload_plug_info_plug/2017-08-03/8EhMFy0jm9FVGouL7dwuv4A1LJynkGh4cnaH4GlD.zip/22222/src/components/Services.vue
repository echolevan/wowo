<template>
  <div class='service-list'>
    <md-tabs>
      <md-tab md-label="服务类型">
      </md-tab>
    </md-tabs>
    <md-layout md-gutter style='padding: 40px 40px'>
      <md-layout class='washer-info' md-flex="25" v-for="serv in services" :key="serv.id"  style='padding: 20px'>
        <md-card>
          <md-card-header>
            <md-card-header-text>
              <div class="md-title">{{serv.name}}</div>
              <div class="md-subhead">{{serv.time}} 分钟 {{serv.price}}元</div>
            </md-card-header-text>

            <md-card-media>
              <img :src="serv.icon" />
            </md-card-media>
          </md-card-header>

          <md-card-content>
            操作码：{{serv.op_key}}={{serv.op_value}}
          </md-card-content>

          <md-card-actions>
            <md-button @click.native="openDelete('delete-service', serv)">删除</md-button>
            <md-button @click.native="openEdit('add-service-form', serv)">编辑</md-button>
          </md-card-actions>
        </md-card>
      </md-layout>
    </md-layout>
    <md-dialog-confirm
      :md-title="confirm.title"
      :md-content-html="confirm.contentHtml"
      :md-ok-text="confirm.ok"
      :md-cancel-text="confirm.cancel"
      @close="onConfirmClose"
      ref="delete-service">
    </md-dialog-confirm>
    <md-dialog md-open-from="#add-service" md-close-to="#add-service" ref="add-service-form" class='add-service'>
      <md-dialog-title>{{title}}</md-dialog-title>
      <md-dialog-content>
        <form novalidate @submit.stop.prevent="submit">
          <md-input-container>
            <label>类型(名称)</label>
            <md-input v-model="service.name"></md-input>
          </md-input-container>
          <md-input-container>
            <label>时长(分钟)</label>
            <md-input v-model="service.time"></md-input>
          </md-input-container>
          <md-input-container>
            <label>价格(元)</label>
            <md-input v-model="service.price"></md-input>
          </md-input-container>
          <md-input-container>
            <label>操作码: key</label>
            <md-input v-model="service.op_key"></md-input>
          </md-input-container>
          <md-input-container>
            <label>操作码: value</label>
            <md-input v-model="service.op_value"></md-input>
          </md-input-container>
          <md-input-container>
            <label>Icon</label>
            <md-file  v-model="service.image_icon" @change.native="iconChange($event)"></md-file>
          </md-input-container>
        </form>
      </md-dialog-content>
      <md-dialog-actions>
        <md-button class="md-primary" @click.native="cancelDialog('add-service-form')">取消</md-button>
        <md-button class="md-primary" @click.native="submitDialog('add-service-form')" :disabled="disableSubmit">确认提交</md-button>
      </md-dialog-actions>
    </md-dialog>
    <md-button class="md-fab md-fab-top-right" @click.native="openDialog('add-service-form')">
      <md-icon>add</md-icon>
    </md-button>
  </div>
</template>

<script>

import tools from '../tools'

export default {
  data() {
    return {
      service: {},
      services: [],
      title: '添加服务',
      disableSubmit: false,
      confirm: {
        title: `确认删除该服务类型吗？`,
        contentHtml: '删除现有的服务类型可能会影响到用户的正常使用，请谨慎操作',
        ok: '确定删除',
        cancel: '取消'
      }
    }
  },
  mounted() {
    this.getServices()
  },
  methods: {
    async onConfirmClose(type) {
      if (type === 'ok') {
        try {
          await this.$http.delete(`services/${this.service.id}`, this.service)
          this.services = this.services.filter(serv => serv.id !== this.service.id)
          this.$store.dispatch('success', '删除成功')
        } catch (e) {
          this.$store.dispatch('success', '删除失败')
        }
      }
    },
    iconChange(e) {
      tools.toBase64(e.target.files[0], (res) => {
        this.service.icon = res
      })
    },
    async getServices() {
      let res = await this.$resource('services').get()
      this.services = res.body
    },
    openEdit(ref, serv) {
      this.service = serv
      this.disableSubmit = false
      this.$refs[ref].open()
    },
    openDelete(ref, serv) {
      this.service = serv
      this.$refs[ref].open()
    },
    openDialog(ref) {
      this.disableSubmit = false
      this.$refs[ref].open()
    },
    editService(service, ref) {
      this.service = service
      this.$refs[ref].open()
    },
    cancelDialog(ref) {
      this.$refs[ref].close()
    },
    async submitDialog(ref) {
      this.disableSubmit = true
      try {
        if (this.service.id) {
          await this.$http.put(`services/${this.service.id}`, this.service)
          this.$store.dispatch('success', '更新成功')
        } else {
          let res = await this.$http.post('services', this.service)
          this.services.push(res.body)
          this.$store.dispatch('success', '创建成功')
        }
        this.$refs[ref].close()
      } catch (e) {
        this.$store.dispatch('error', e.body.message)
      }
    }
  }
}
</script>

<style lang="scss" scoped>
.md-card {
  width: 100%;
}
.service-list {
  .md-table .md-table-head, .md-table .md-table-cell {
    font-size: 16px;
  }
  .md-table-row {
    cursor: pointer;
    img {
      margin: auto;
      height: 80px;
      width: 80px;
    }
    .edit-service {
      margin: auto;
    }
  }
}
.md-fab.md-fab-top-right, .md-speed-dial.md-fab-top-right {
  top: 20px;
  right: 10px;
}
</style>
