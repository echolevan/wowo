<template>
  <md-whiteframe md-elevation="1">
    <figure :style="figureStyle"><chart :options="options" auto-resize :style="chartStyle" theme="macarons"></chart></figure>
  </md-whiteframe>
</template>

<script>
  export default {
    props: {
      data: {
        type: Array,
        required: true
      },
      xAxisData: {
        type: Array,
        required: true
      },
      name: String,
      title: {
        type: String,
        required: true
      },
      chartStyle: {
        type: Object
      },
      figureStyle: {
        type: Object
      }
    },
    name: 'ChartBar',
    data() {
      return {
        options: {
          title: {
            text: this.title,
            x: 'center',
            textStyle: {
              fontSize: 14
            }
          },
          tooltip: {},
          xAxis: {
            data: []
          },
          yAxis: {},
          series: [{
            name: this.name || this.title,
            type: 'bar',
            data: [],
            markPoint: {
              data: [
                {type: 'max', name: '最大值'},
                {type: 'min', name: '最小值'}
              ]
            },
            markLine: {
              data: [
                {type: 'average', name: '平均值'}
              ]
            }
          }]
        }
      }
    },
    watch: {
      data(val) {
        this.setData(val)
      },
      xAxisData(val) {
        this.options.xAxis.data = val
      }
    },
    methods: {
      setData(data) {
        if (!Array.isArray(data[0])) {
          data = [data]
        }
        this.options.series = data.map((item) => {
          return {
            name: this.name || this.title,
            type: 'bar',
            data: item,
            markPoint: {
              data: [
                {type: 'max', name: '最大值'},
                {type: 'min', name: '最小值'}
              ]
            },
            markLine: {
              data: [
                {type: 'average', name: '平均值'}
              ]
            }
          }
        })
      }
    }
  }
</script>

<style lang="scss" scoped>
.md-whiteframe {
  cursor: pointer;
  &:hover {
    border: 1px solid #03A9F4;
    font-weight: bold;
  }
}
figure {
  width: 100%;
  margin: 0px;
}
.echarts {
  height: 220px;
  width: 100%;
}
</style>
