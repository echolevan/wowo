<template>
  <div>
    <md-whiteframe md-elevation="1" class='list-title'>
      <md-layout md-gutter>
        <md-layout md-flex="25">
          <strong>共 {{washers.length}} 台洗衣机</strong>
        </md-layout>
      </md-layout>
    </md-whiteframe>
    <md-layout md-gutter>
      <md-layout class='washer-info' md-flex="25" v-for="washer in washers" :key="washer.id">
        <washer-card :washer="washer" :stats="statsData[washer.id] || {}"></washer-card>
      </md-layout>
    </md-layout>
  </div>
</template>

<script>

import WasherCard from './WasherCard'
import { mapState, mapGetters } from 'vuex'

export default {
  components: { WasherCard },
  computed: {
    ...mapState(['washers']),
    ...mapGetters(['washerIds']),
    ...mapGetters({
      statsData: 'orderCountByWasherStats'
    })
  },
  data() { return {} },
  mounted() {},
  methods: {}
}
</script>
<style lang="scss" scoped>
.list-title {
  margin: 0px 20px 20px 0px;
  padding: 10px 20px;
  background: #fff;
  font-size: 16px;
  height: 40px;
}
.washer-info {
  padding: 0px 20px 20px 0px;
}
</style>
