import router from './router'
import user from './user'

router.beforeEach((to, from, next) => {
  let u = user.current
  if (u || to.name === 'Login' || from.name === 'Login') {
    if (u && u.user_type === 10 && to.name !== 'HaierTest') {
      next('/haier_test')
    } else {
      next()
    }
  } else {
    next('/login')
  }
})
