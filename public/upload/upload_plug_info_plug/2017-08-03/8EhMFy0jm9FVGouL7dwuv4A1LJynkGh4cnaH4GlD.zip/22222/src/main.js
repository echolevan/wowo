// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import router from './router'
import './router_hook'
import './assets/css/meterial-icons.css'
import './assets/css/roboto-font.css'
import 'vue2-animate/dist/vue2-animate.min.css'
import './assets/css/global.scss'

import VueMaterial from 'vue-material'
// import Datepicker from 'vue-datepicker'
import ECharts from 'vue-echarts/components/ECharts.vue'
import 'echarts/lib/chart/bar'
import 'echarts/lib/component/tooltip'
import 'vue-material/dist/vue-material.css'
import 'echarts/theme/macarons'
import 'echarts/theme/dark'
import 'echarts/theme/infographic'
import 'echarts/theme/roma'
import 'echarts/theme/shine'
import 'echarts/theme/vintage'

import VueResource from 'vue-resource'

import App from './App'

Vue.config.productionTip = false
Vue.config.apiHost = process.env.API_HOST

Vue.use(VueMaterial)
Vue.material.registerTheme('default', {
  primary: 'light-blue'
})

import walden from './walden.json'
ECharts.registerTheme('walden', walden)
Vue.component('chart', ECharts)

import VueMoment from 'vue-moment-jalaali'
import 'moment/locale/zh-cn'

Vue.use(VueMoment)

import Datepicker from './vue-datepicker-es6.vue'
Vue.component('datepicker', Datepicker)

import store from './store'

Vue.use(VueResource)
Vue.http.options.root = Vue.config.apiHost + '/api/v1'

Vue.http.interceptors.push(function(request, next) {
  store.commit('showSpinner')
  next(function(response) {
    store.commit('hideSpinner')
  })
})

import Auth from './auth'
Vue.use(Auth)
import User from './user'
Vue.use(User)

import mdTablePagination from './mdTablePagination'
Vue.component('md-table-pagination', mdTablePagination)

/* eslint-disable no-new */
new Vue({
  el: '#app',
  router,
  store,
  template: '<App/>',
  components: { App }
})
