import Vue from 'vue'
import user from './user'
import router from './router'
const LOGIN_URL = 'tokens'
const REFRESH_TOKEN_URL = 'refresh_token'

export default {
  install(Vue, options) {
    Vue.http.interceptors.push((request, next) => {
      if (user.login) request.headers.set('Authorization', 'Bearer ' + user.access_token)

      next((response) => {
        if (this._isInvalidToken(response)) return this._refreshToken(request)
      })
    })
    Vue.prototype.$auth = Vue.auth = this
  },

  async login(user) {
    try {
      return await Vue.http.post(LOGIN_URL, user)
    } catch (e) {
      return e
    }
  },

  _isInvalidToken(response) {
    return (response.status === 401 && response.data.status === 'token_error')
  },

  _logout() {
    user.logout()
    this.$store.dispatch('error', '登录信息已失效，请重新登录')
    router.push({ name: 'Login' })
  },

  _retry(request) {
    return Vue.http(request)
      .then((response) => {
        return response
      })
      .catch((response) => {
        return response
      })
  },

  _refreshToken(request) {
    if (!user.refresh_token) this._logout()
    let options = {
      headers: {
        Authorization: 'Bearer ' + user.refresh_token
      }
    }
    return Vue.http.post(REFRESH_TOKEN_URL, {}, options).then((response) => {
      user.access_token = response.body.access_token
      return this._retry(request)
    }).catch((response) => {
      this._logout()
    })
  }
}
