<template>
  <div id='app' style='height: 100vh'>
    <div id='spinner-container'>
      <md-spinner :md-size="80" :md-stroke="2.5" v-if="showSpinner" md-indeterminate class="md-accent"></md-spinner>
    </div>
    <md-snackbar :md-position="alert.position" class='my-alert' ref="snackbar" :md-duration="alert.duration" v-bind:class='["md-"+alert.type]'>
      <span>{{alert.message}}</span>
      <md-icon class='close' @click.native="$refs.snackbar.close()">close</md-icon>
    </md-snackbar>
    <div class='flat-container full-height' v-if="!hasSidebar()">
      <router-view></router-view>
    </div>
    <div class='container full-height' v-if="hasSidebar()">
      <left-side-bar></left-side-bar>
      <div class='page-content'>
        <div class='main-content component-docs full-height'>
          <router-view></router-view>
        </div>
      </div>
    </div>
    <div v-if="hasSidebar()">
      <md-speed-dial md-open="hover" class="md-fab-bottom-left">
        <md-button class="md-fab" md-fab-trigger>
          <md-icon md-icon-morph>close</md-icon>
          <md-icon>person_outlet</md-icon>
        </md-button>

        <md-button class="md-fab md-primary md-mini md-clean" @click.native='goToUser()'>
          <md-icon>person_outlet</md-icon>
          <md-tooltip md-direction="right">个人信息</md-tooltip>
        </md-button>

        <md-button class="md-fab md-primary md-mini md-clean" @click.native='logout'>
          <md-icon>exit_to_app</md-icon>
          <md-tooltip md-direction="right">登出</md-tooltip>
        </md-button>

      </md-speed-dial>
    </div>
  </div>
</template>

<script>

import router from './router'
import { mapState } from 'vuex'
import LeftSideBar from './components/LeftSideBar'

export default {
  name: 'app',
  computed: mapState(['showSpinner', 'alert']),
  data() {
    return {
      noSidebarRoutes: ['Login', 'HaierTest']
    }
  },
  mounted() {
    this.$store.subscribe((mutation, state) => {
      if (mutation.type === 'changeAlert') {
        this.$refs.snackbar.open()
      }
    })
  },
  methods: {
    hasSidebar() {
      return this.noSidebarRoutes.indexOf(this.$route.name) === -1
    },
    goToUser() {
      router.push({ name: 'Worker', params: { wid: this.$user.current.id } })
    },
    logout() {
      this.$user.logout()
      this.$store.dispatch('success', '您已登出', 'top center')
      router.push({ name: 'Login' })
    }
  },
  components: { LeftSideBar }
}
</script>

<style lang="scss">
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
}
.container {
  min-height: 100%;
  -ms-flex-flow: column nowrap;
  flex-flow: column nowrap;
  -ms-flex: 1;
  flex: 1;
  transition: all .4s cubic-bezier(.25,.8,.25,1);
  display: flex;
  display: -ms-flexbox;
  padding-left: 150px;
}
.page-content {
  min-height: 100%;
  -ms-flex: 1;
  flex: 1;
  display: -ms-flexbox;
  display: flex;
  -ms-flex-flow: column;
  flex-flow: column;
}
.flat-container {
  background: #f4f7ed;
}
.btn-logout {
  position: absolute;
  right: 0px;
  top: 8px;
}
#spinner-container {
  width: 100%;
  text-align: center;
  position: absolute;
  z-index: 10000;
  top: 30%;
}
.md-toolbar {
  min-height: 45px;
}
.md-toolbar .md-title {
  font-size: 16px;
}
.md-speed-dial.md-fab-bottom-left {
  left: 47px;
}
.md-speed-dial.md-fab-bottom-right, .md-speed-dial.md-fab-bottom-left {
  z-index: 10000;
  position: fixed;
}
</style>
