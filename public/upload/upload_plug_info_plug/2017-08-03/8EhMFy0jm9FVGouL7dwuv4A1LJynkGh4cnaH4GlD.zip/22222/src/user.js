export default {
  install(Vue, options) {
    Vue.prototype.$user = Vue.user = this
  },
  set tokens(tokens) {
    localStorage.setItem('access_token', tokens.access_token)
    localStorage.setItem('refresh_token', tokens.refresh_token)
  },
  set access_token(token) {
    localStorage.setItem('access_token', token)
  },
  set refresh_token(token) {
    localStorage.setItem('refresh_token', token)
  },
  get access_token() {
    return localStorage.getItem('access_token')
  },
  get refresh_token() {
    return localStorage.getItem('refresh_token')
  },
  get current() {
    return JSON.parse(localStorage.getItem('current_user'))
  },
  get login() {
    return !!this.access_token
  },
  logout() {
    localStorage.removeItem('access_token')
    localStorage.removeItem('refresh_token')
    localStorage.removeItem('current_user')
  }
}
